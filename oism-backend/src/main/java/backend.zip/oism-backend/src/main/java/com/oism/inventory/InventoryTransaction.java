package com.oism.inventory;

import com.oism.tenant.TenantAwareEntity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Immutable;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/** Ledger APPEND-ONLY: @Immutable (app-level) + trigger trg_ledger_no_update_delete (DB-level). */
@Entity @Table(name = "inventory_transactions") @Immutable
@Getter @Setter @NoArgsConstructor
public class InventoryTransaction extends TenantAwareEntity {
    public enum Type { IN, OUT }
    public enum Reason { IMPORT, EXPORT, SALE, RETURN, STOCKTAKE, TRANSFER_OUT, TRANSFER_IN, ADJUSTMENT }

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "branch_id", nullable = false) private UUID branchId;
    @Column(name = "sku_id", nullable = false) private UUID skuId;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private Type type;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private Reason reason;
    @Column(nullable = false) private int quantity;
    @Column(name = "balance_after", nullable = false) private int balanceAfter;
    @Column(name = "unit_cost") private BigDecimal unitCost;
    @Column(name = "reference_type") private String referenceType;
    @Column(name = "reference_id") private UUID referenceId;
    private String note;
    @Column(name = "created_by") private UUID createdBy;
    @Column(name = "created_at", nullable = false, updatable = false) private Instant createdAt = Instant.now();
}
