package com.oism;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OismApplication {
    public static void main(String[] args) {
        SpringApplication.run(OismApplication.class, args);
    }
}
