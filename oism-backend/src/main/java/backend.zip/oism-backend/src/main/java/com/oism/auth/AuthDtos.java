package com.oism.auth;

import jakarta.validation.constraints.*;
import java.util.UUID;

public final class AuthDtos {
    private AuthDtos() {}

    public record RegisterTenantRequest(
            @NotBlank @Pattern(regexp = "[a-zA-Z0-9_-]{3,50}") String tenantCode,
            @NotBlank String storeName,
            @NotBlank String ownerName,
            @Email String email,
            String phone,
            @NotBlank @Size(min = 8, max = 72) String password) {}

    public record LoginRequest(@NotBlank String identifier, @NotBlank String password) {}

    public record AuthResponse(String accessToken, String tokenType, long expiresInSeconds,
                               UUID tenantId, UUID userId, Role role) {}
}
