package com.oism.inventory;

import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.UUID;

public interface StockLevelRepository extends JpaRepository<StockLevel, Long> {
    /** SELECT ... FOR UPDATE: các request đồng thời trên cùng SKU được xếp hàng tuần tự (NFR-PERF-02). */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select s from StockLevel s where s.branchId = :branchId and s.skuId = :skuId")
    Optional<StockLevel> findForUpdate(@Param("branchId") UUID branchId, @Param("skuId") UUID skuId);
}
