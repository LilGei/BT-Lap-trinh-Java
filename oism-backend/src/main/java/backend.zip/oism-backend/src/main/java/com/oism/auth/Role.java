package com.oism.auth;

public enum Role { OWNER, STAFF, CASHIER }
