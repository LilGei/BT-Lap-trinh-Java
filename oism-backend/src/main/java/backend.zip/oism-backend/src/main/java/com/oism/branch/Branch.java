package com.oism.branch;

import com.oism.tenant.TenantAwareEntity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

@Entity @Table(name = "branches")
@Getter @Setter @NoArgsConstructor
public class Branch extends TenantAwareEntity {
    @Id @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    @Column(nullable = false) private String code;
    @Column(nullable = false) private String name;
    private String address;
    @Column(name = "is_warehouse") private boolean warehouse;
    private boolean active = true;
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt = Instant.now();
}
