package com.oism.inventory;

import com.oism.tenant.TenantAwareEntity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

@Entity @Table(name = "stock_levels")
@Getter @Setter @NoArgsConstructor
public class StockLevel extends TenantAwareEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "branch_id", nullable = false) private UUID branchId;
    @Column(name = "sku_id", nullable = false) private UUID skuId;
    @Column(name = "on_hand", nullable = false) private int onHand;
    @Column(nullable = false) private int reserved;
    @Column(name = "reorder_point", nullable = false) private int reorderPoint;
    @Version private long version;
    @Column(name = "updated_at", nullable = false) private Instant updatedAt = Instant.now();

    /** FR-RSE-01: available = on_hand - reserved */
    public int available() { return onHand - reserved; }
}
