package com.oism.auth;

import com.oism.auth.AuthDtos.*;
import com.oism.common.BusinessException;
import com.oism.tenant.Tenant;
import com.oism.tenant.TenantRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthService {
    private final TenantRepository tenants;
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final JwtService jwt;

    /** FR-AUTH-01: tạo Tenant mới + tài khoản Owner. */
    @Transactional
    public AuthResponse registerTenant(RegisterTenantRequest r) {
        boolean hasEmail = r.email() != null && !r.email().isBlank();
        boolean hasPhone = r.phone() != null && !r.phone().isBlank();
        if (!hasEmail && !hasPhone)
            throw new BusinessException(HttpStatus.BAD_REQUEST, "Email or phone is required");
        if (tenants.existsByCodeIgnoreCase(r.tenantCode()))
            throw new BusinessException(HttpStatus.CONFLICT, "Tenant code already exists");
        if (hasEmail && users.existsByEmailIgnoreCase(r.email()))
            throw new BusinessException(HttpStatus.CONFLICT, "Email already used");
        if (hasPhone && users.existsByPhone(r.phone()))
            throw new BusinessException(HttpStatus.CONFLICT, "Phone already used");

        Tenant t = new Tenant();
        t.setCode(r.tenantCode());
        t.setName(r.storeName());
        t = tenants.save(t);

        User u = new User();
        u.setTenantId(t.getId());
        u.setEmail(hasEmail ? r.email() : null);
        u.setPhone(hasPhone ? r.phone() : null);
        u.setFullName(r.ownerName());
        u.setPasswordHash(encoder.encode(r.password()));
        u.setRole(Role.OWNER);
        u = users.save(u);
        return toResponse(u);
    }

    /** FR-AUTH-02 */
    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest r) {
        User u = users.findByIdentifier(r.identifier())
                .filter(User::isActive)
                .filter(x -> encoder.matches(r.password(), x.getPasswordHash()))
                .orElseThrow(() -> new BusinessException(HttpStatus.UNAUTHORIZED, "Invalid credentials"));
        return toResponse(u);
    }

    private AuthResponse toResponse(User u) {
        return new AuthResponse(jwt.generate(u), "Bearer", jwt.ttlSeconds(),
                u.getTenantId(), u.getId(), u.getRole());
    }
}
