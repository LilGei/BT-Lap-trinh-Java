package com.oism.inventory;

import com.oism.common.InsufficientStockException;
import com.oism.inventory.InventoryTransaction.Reason;
import com.oism.inventory.InventoryTransaction.Type;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/**
 * Cổng DUY NHẤT được phép thay đổi tồn kho. Mọi thay đổi on_hand đều đi kèm 1 dòng ledger
 * trong CÙNG transaction (MANDATORY => phải được gọi từ transaction của use case: ACID, NFR-SEC-02).
 */
@Service
@RequiredArgsConstructor
public class InventoryService {
    private final StockLevelRepository stocks;
    private final InventoryTransactionRepository ledger;

    /** FR-RSE-02: giữ hàng cho đơn online. Từ chối nếu available < qty. */
    @Transactional(propagation = Propagation.MANDATORY)
    public void reserve(UUID branchId, UUID skuId, int qty) {
        StockLevel s = lock(branchId, skuId);
        if (s.available() < qty) throw new InsufficientStockException(s.available(), qty);
        s.setReserved(s.getReserved() + qty);
        s.setUpdatedAt(Instant.now());
    }

    /** FR-RSE-03 (Cancelled): trả hàng giữ về available. */
    @Transactional(propagation = Propagation.MANDATORY)
    public void release(UUID branchId, UUID skuId, int qty) {
        StockLevel s = lock(branchId, skuId);
        s.setReserved(Math.max(0, s.getReserved() - qty));
        s.setUpdatedAt(Instant.now());
    }

    /** FR-RSE-03 (Confirmed): trừ on_hand, giảm reserved, ghi ledger OUT. */
    @Transactional(propagation = Propagation.MANDATORY)
    public void deductReserved(UUID branchId, UUID skuId, int qty, Reason reason,
                               String refType, UUID refId, UUID userId) {
        StockLevel s = lock(branchId, skuId);
        if (s.getReserved() < qty) throw new InsufficientStockException(s.getReserved(), qty);
        s.setOnHand(s.getOnHand() - qty);
        s.setReserved(s.getReserved() - qty);
        s.setUpdatedAt(Instant.now());
        append(s, Type.OUT, reason, qty, null, refType, refId, userId);
    }

    /** FR-INV-02: nhập kho -> tăng on_hand + ghi ledger IN. (Tính bình quân gia quyền: bước tiếp theo.) */
    @Transactional(propagation = Propagation.MANDATORY)
    public void receive(UUID branchId, UUID skuId, int qty, BigDecimal unitCost, Reason reason,
                        String refType, UUID refId, UUID userId) {
        StockLevel s = stocks.findForUpdate(branchId, skuId).orElseGet(() -> {
            StockLevel n = new StockLevel();
            n.setBranchId(branchId); n.setSkuId(skuId);
            return stocks.saveAndFlush(n);
        });
        s.setOnHand(s.getOnHand() + qty);
        s.setUpdatedAt(Instant.now());
        append(s, Type.IN, reason, qty, unitCost, refType, refId, userId);
    }

    private StockLevel lock(UUID branchId, UUID skuId) {
        return stocks.findForUpdate(branchId, skuId)
                .orElseThrow(() -> new InsufficientStockException(0, 1));
    }

    private void append(StockLevel s, Type type, Reason reason, int qty, BigDecimal cost,
                        String refType, UUID refId, UUID userId) {
        InventoryTransaction t = new InventoryTransaction();
        t.setBranchId(s.getBranchId()); t.setSkuId(s.getSkuId());
        t.setType(type); t.setReason(reason); t.setQuantity(qty);
        t.setBalanceAfter(s.getOnHand()); t.setUnitCost(cost);
        t.setReferenceType(refType); t.setReferenceId(refId); t.setCreatedBy(userId);
        ledger.save(t);
    }
}
