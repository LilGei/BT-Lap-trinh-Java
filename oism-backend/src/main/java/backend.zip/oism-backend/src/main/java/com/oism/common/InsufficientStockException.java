package com.oism.common;

import org.springframework.http.HttpStatus;

public class InsufficientStockException extends BusinessException {
    public InsufficientStockException(int available, int requested) {
        super(HttpStatus.CONFLICT, "Insufficient stock: available=" + available + ", requested=" + requested);
    }
}
