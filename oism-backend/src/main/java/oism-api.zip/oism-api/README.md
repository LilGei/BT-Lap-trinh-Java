# OISM – BỘ API

Bộ này chứa **toàn bộ code API**: controller (nơi khai báo URL), DTO (JSON vào/ra), service (logic nghiệp vụ),
bảo mật/JWT, xử lý lỗi, và các test. Bộ này **không có file SQL, entity, repository** (nằm ở bộ `oism-database`).

## Cách dùng
1. Giải nén **vào đúng thư mục project** (thư mục có `pom.xml`), giữ nguyên cấu trúc thư mục, cùng chỗ với bộ `oism-database`.
2. Nếu Windows hỏi trùng file, chọn **Replace**.
3. Các file cấu hình gói 1 (`pom.xml`, `application.yml`, `Dockerfile`, `docker-compose.yml`) không đổi nên không nằm trong bộ này.
4. Chạy test: tạo DB `oism_test` một lần (`CREATE DATABASE oism_test OWNER oism;`) rồi mở tab Testing của VS Code.

> Lưu ý: chỉ riêng bộ này **không biên dịch được** vì code API dùng entity/repository của bộ database. Cần cả hai bộ.

## Các API (khai báo trong các file `...Controller.java`)
| Nhóm | Endpoint | Vai trò |
|---|---|---|
| Auth | POST /api/auth/register-tenant, /login, /refresh, /logout | public |
| Users | GET/POST /api/users, PUT /{id}/branches, PATCH /{id}/status | OWNER |
| Branch | GET/POST /api/branches, PATCH /{id}/active | đọc: all, ghi: OWNER |
| Category / Brand | /api/categories, /api/brands | đọc: all, ghi: OWNER |
| Product / SKU | /api/products, POST /api/products/{id}/variants | đọc: all, ghi: OWNER, STAFF |
| Giá niêm yết | PUT /api/variants/{id}/prices | OWNER |
| Ngưỡng tồn thấp | PUT /api/variants/{id}/reorder-threshold | OWNER, STAFF |
| Barcode | POST /api/variants/{id}/barcodes, POST .../barcodes/generate, DELETE .../barcodes/{barcodeId}, GET /api/variants/by-barcode/{code} | ghi: OWNER, STAFF |
| Tìm hàng POS | GET /api/variants/search?q= | all |
| Nhà cung cấp, Phiếu nhập | /api/suppliers, /api/purchase-receipts (+ /{id}/confirm, /cancel) | OWNER, STAFF |
| Chuyển kho | /api/stock-transfers (+ /{id}/ship, /receive, /cancel) | OWNER, STAFF |
| Kiểm kê | /api/stocktakes (+ PUT /{id}/counts, POST /{id}/complete, DELETE /{id}) | OWNER, STAFF |
| Tồn kho, Sổ cái | GET /api/inventory/stock, GET /api/inventory/ledger | tồn: all, sổ cái: OWNER, STAFF |

## Danh sách file
| File | Vai trò | Trạng thái |
|---|---|---|
| `…/oism/auth/AuthController.java` | API endpoint (Controller) | SỬA |
| `…/oism/branch/BranchController.java` | API endpoint (Controller) | SỬA |
| `…/oism/catalog/BrandController.java` | API endpoint (Controller) | SỬA |
| `…/oism/catalog/CategoryController.java` | API endpoint (Controller) | SỬA |
| `…/oism/catalog/ProductController.java` | API endpoint (Controller) | SỬA |
| `…/oism/inventory/InventoryController.java` | API endpoint (Controller) | SỬA |
| `…/oism/inventory/StockTransferController.java` | API endpoint (Controller) | giữ nguyên |
| `…/oism/inventory/StocktakeController.java` | API endpoint (Controller) | SỬA |
| `…/oism/purchasing/PurchaseController.java` | API endpoint (Controller) | giữ nguyên |
| `…/oism/user/UserController.java` | API endpoint (Controller) | SỬA |
| `…/oism/auth/AuthUser.java` | Bảo mật / JWT | SỬA |
| `…/oism/auth/JwtAuthFilter.java` | Bảo mật / JWT | SỬA |
| `…/oism/auth/SecurityConfig.java` | Bảo mật / JWT | giữ nguyên |
| `src/test/resources/application-test.yml` | Cấu hình test | giữ nguyên |
| `…/oism/common/BusinessException.java` | Dùng chung (lỗi, phân trang, sinh mã) | giữ nguyên |
| `…/oism/common/EntityLookup.java` | Dùng chung (lỗi, phân trang, sinh mã) | giữ nguyên |
| `…/oism/common/GlobalExceptionHandler.java` | Dùng chung (lỗi, phân trang, sinh mã) | giữ nguyên |
| `…/oism/common/InsufficientStockException.java` | Dùng chung (lỗi, phân trang, sinh mã) | SỬA |
| `…/oism/common/PageDto.java` | Dùng chung (lỗi, phân trang, sinh mã) | giữ nguyên |
| `…/oism/auth/AuthDtos.java` | Dữ liệu vào/ra của API (DTO) | SỬA |
| `…/oism/catalog/CatalogDtos.java` | Dữ liệu vào/ra của API (DTO) | SỬA |
| `…/oism/inventory/InventoryDtos.java` | Dữ liệu vào/ra của API (DTO) | SỬA |
| `…/oism/purchasing/PurchaseDtos.java` | Dữ liệu vào/ra của API (DTO) | SỬA |
| `…/oism/OismApplication.java` | Khởi động ứng dụng | giữ nguyên |
| `…/oism/auth/AuthService.java` | Logic nghiệp vụ (Service) | SỬA |
| `…/oism/auth/JwtService.java` | Logic nghiệp vụ (Service) | SỬA |
| `…/oism/catalog/ProductService.java` | Logic nghiệp vụ (Service) | SỬA |
| `…/oism/common/DocumentNumberService.java` | Logic nghiệp vụ (Service) | giữ nguyên |
| `…/oism/inventory/InventoryQueryService.java` | Logic nghiệp vụ (Service) | SỬA |
| `…/oism/inventory/InventoryService.java` | Logic nghiệp vụ (Service) | SỬA |
| `…/oism/inventory/StockTransferService.java` | Logic nghiệp vụ (Service) | SỬA |
| `…/oism/inventory/StocktakeService.java` | Logic nghiệp vụ (Service) | SỬA |
| `…/oism/purchasing/PurchaseService.java` | Logic nghiệp vụ (Service) | SỬA |
| `…/oism/catalog/BarcodeUtil.java` | Logic thuần (giá vốn / barcode) | SỬA |
| `…/oism/cost/CostCalculator.java` | Logic thuần (giá vốn / barcode) | SỬA |
| `src/test/java/com/oism/auth/AuthRefreshIT.java` | Test | MỚI |
| `src/test/java/com/oism/catalog/AntiOversellConcurrencyIT.java` | Test | SỬA |
| `src/test/java/com/oism/catalog/BarcodeUtilTest.java` | Test | SỬA |
| `src/test/java/com/oism/catalog/LedgerIntegrityIT.java` | Test | SỬA |
| `src/test/java/com/oism/catalog/ProductApiIT.java` | Test | SỬA |
| `src/test/java/com/oism/catalog/PurchaseCostIT.java` | Test | SỬA |
| `src/test/java/com/oism/catalog/SchemaMatchesClassDiagramIT.java` | Test | MỚI |
| `src/test/java/com/oism/catalog/TenantIsolationIT.java` | Test | SỬA |
| `src/test/java/com/oism/catalog/TransferStocktakeIT.java` | Test | SỬA |
| `src/test/java/com/oism/cost/CostCalculatorTest.java` | Test | giữ nguyên |
| `src/test/java/com/oism/support/IntegrationTestBase.java` | Test | SỬA |

Ghi chú trạng thái: **MỚI** = file mới; **SỬA** = đã đổi nội dung so với bản trước; giữ nguyên = không đổi.
