package com.oism.cost;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class CostCalculatorTest {

    private static BigDecimal bd(String s) { return new BigDecimal(s); }

    @Test
    void firstImportWithNoStockTakesImportPrice() {
        assertThat(CostCalculator.weightedAverage(0, bd("0"), 10, bd("100")))
                .isEqualByComparingTo("100.0000");
    }

    @Test
    void formulaFromRequirementDocument() {
        // (10*100 + 10*200) / 20 = 150
        assertThat(CostCalculator.weightedAverage(10, bd("100"), 10, bd("200")))
                .isEqualByComparingTo("150.0000");
    }

    @Test
    void unevenQuantitiesWeightTowardLargerLot() {
        // (90*10 + 10*20) / 100 = 11
        assertThat(CostCalculator.weightedAverage(90, bd("10"), 10, bd("20")))
                .isEqualByComparingTo("11.0000");
    }

    @Test
    void roundsHalfUpToFourDecimals() {
        // (2*10 + 1*11) / 3 = 10.3333...
        assertThat(CostCalculator.weightedAverage(2, bd("10"), 1, bd("11")))
                .isEqualTo(bd("10.3333"));
        // (1*10 + 1*10.0001) / 2 = 10.00005 -> HALF_UP -> 10.0001
        assertThat(CostCalculator.weightedAverage(1, bd("10"), 1, bd("10.0001")))
                .isEqualTo(bd("10.0001"));
    }

    @Test
    void negativeOldStockIsIgnored() {
        assertThat(CostCalculator.weightedAverage(-5, bd("999"), 4, bd("50")))
                .isEqualByComparingTo("50.0000");
    }

    @Test
    void sameCostStaysSame() {
        assertThat(CostCalculator.weightedAverage(7, bd("33.3333"), 3, bd("33.3333")))
                .isEqualByComparingTo("33.3333");
    }

    @Test
    void rejectsInvalidInput() {
        assertThatThrownBy(() -> CostCalculator.weightedAverage(1, bd("1"), 0, bd("1")))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> CostCalculator.weightedAverage(1, bd("1"), 1, bd("-1")))
                .isInstanceOf(IllegalArgumentException.class);
    }
}
