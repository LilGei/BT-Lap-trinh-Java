package com.oism.catalog;

import com.fasterxml.jackson.databind.JsonNode;
import com.oism.support.IntegrationTestBase;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/** FR-INV-03 (chuyển kho 2 bước) và FR-INV-04 (kiểm kê). */
class TransferStocktakeIT extends IntegrationTestBase {

    private JsonNode transfer(Session s, UUID from, UUID to, UUID sku, Object qty, int expected) throws Exception {
        return post("/api/stock-transfers", s, m("fromBranchId", from, "toBranchId", to,
                "items", List.of(m("skuId", sku, "quantity", qty))), expected);
    }

    private JsonNode count(Session s, String stocktakeId, UUID sku, Object qty) throws Exception {
        return put("/api/stocktakes/" + stocktakeId + "/counts", s,
                m("items", List.of(m("skuId", sku, "actualQty", qty))), 200);
    }

    @Test
    void twoStepTransferMovesStockAndWritesLedger() throws Exception {
        Session s = registerTenant();
        UUID a = createBranch(s, "A");
        UUID b = createBranch(s, "B");
        UUID sku = firstSkuId(createProduct(s, "Hàng", "TR-1", "10"));
        stockIn(s, a, sku, 20, "10");

        JsonNode t = transfer(s, a, b, sku, 5, 201);
        String id = t.get("id").asText();
        assertThat(t.get("status").asText()).isEqualTo("DRAFT");
        assertThat(t.get("code").asText()).startsWith("CK-");
        assertThat(onHand(s, a, sku)).isEqualTo(20);   // DRAFT chưa đổi tồn

        // bước 1: xuất kho gửi
        assertThat(post("/api/stock-transfers/" + id + "/ship", s, null, 200).get("status").asText()).isEqualTo("IN_TRANSIT");
        assertThat(onHand(s, a, sku)).isEqualTo(15);
        assertThat(onHand(s, b, sku)).isZero();        // đang trên đường, kho nhận chưa có
        post("/api/stock-transfers/" + id + "/ship", s, null, 409);      // không xuất 2 lần
        post("/api/stock-transfers/" + id + "/cancel", s, null, 409);    // đã xuất thì không huỷ

        // bước 2: kho nhận xác nhận
        assertThat(post("/api/stock-transfers/" + id + "/receive", s, null, 200).get("status").asText()).isEqualTo("RECEIVED");
        assertThat(onHand(s, b, sku)).isEqualTo(5);
        post("/api/stock-transfers/" + id + "/receive", s, null, 409);   // không nhận 2 lần
        assertThat(onHand(s, a, sku) + onHand(s, b, sku)).isEqualTo(20); // tổng tồn không đổi

        long outs = 0, ins = 0;
        for (JsonNode r : get("/api/inventory/ledger?skuId=" + sku, s).get("content")) {
            if (r.get("referenceType").asText().equals("TRANSFER_OUT")) { outs++; assertThat(r.get("type").asText()).isEqualTo("OUT"); }
            if (r.get("referenceType").asText().equals("TRANSFER_IN")) { ins++; assertThat(r.get("type").asText()).isEqualTo("IN"); }
        }
        assertThat(outs).isEqualTo(1);
        assertThat(ins).isEqualTo(1);
    }

    @Test
    void transferSupportsDecimalQuantity() throws Exception {
        Session s = registerTenant();
        UUID a = createBranch(s, "A");
        UUID b = createBranch(s, "B");
        UUID sku = firstSkuId(createProduct(s, "Gạo", "TR-DEC", "10"));
        stockIn(s, a, sku, "10.5", "10");
        String id = transfer(s, a, b, sku, new BigDecimal("2.25"), 201).get("id").asText();
        post("/api/stock-transfers/" + id + "/ship", s, null, 200);
        post("/api/stock-transfers/" + id + "/receive", s, null, 200);
        assertThat(onHandDecimal(s, a, sku)).isEqualByComparingTo("8.25");
        assertThat(onHandDecimal(s, b, sku)).isEqualByComparingTo("2.25");
    }

    @Test
    void shipFailsAtomicallyWhenStockIsInsufficient() throws Exception {
        Session s = registerTenant();
        UUID a = createBranch(s, "A");
        UUID b = createBranch(s, "B");
        UUID sku1 = firstSkuId(createProduct(s, "H1", "ATOM-1", "10"));
        UUID sku2 = firstSkuId(createProduct(s, "H2", "ATOM-2", "10"));
        stockIn(s, a, sku1, 10, "10");
        stockIn(s, a, sku2, 1, "10");

        // dòng 1 đủ hàng, dòng 2 thiếu => toàn phiếu phải rollback (không trừ dòng 1)
        JsonNode t = post("/api/stock-transfers", s, m("fromBranchId", a, "toBranchId", b, "items", List.of(
                m("skuId", sku1, "quantity", 5), m("skuId", sku2, "quantity", 50))), 201);
        String id = t.get("id").asText();
        post("/api/stock-transfers/" + id + "/ship", s, null, 409);

        assertThat(get("/api/stock-transfers/" + id, s).get("status").asText()).isEqualTo("DRAFT");
        assertThat(onHand(s, a, sku1)).isEqualTo(10);
        assertThat(onHand(s, a, sku2)).isEqualTo(1);
    }

    @Test
    void transferValidation() throws Exception {
        Session s = registerTenant();
        UUID a = createBranch(s, "A");
        UUID b = createBranch(s, "B");
        UUID sku = firstSkuId(createProduct(s, "Hàng", "TV-1", "10"));
        transfer(s, a, a, sku, 1, 400);                       // cùng chi nhánh
        transfer(s, a, UUID.randomUUID(), sku, 1, 404);       // chi nhánh không tồn tại
        transfer(s, a, b, sku, 0, 400);                       // số lượng = 0

        String id = transfer(s, a, b, sku, 1, 201).get("id").asText();
        post("/api/stock-transfers/" + id + "/cancel", s, null, 200);   // DRAFT huỷ được
        post("/api/stock-transfers/" + id + "/ship", s, null, 409);     // đã huỷ không xuất được
    }

    @Test
    void stocktakeAdjustsShortageAndSurplusThroughLedger() throws Exception {
        Session s = registerTenant();
        UUID branch = createBranch(s, "A");
        UUID sku = firstSkuId(createProduct(s, "Hàng", "ST-1", "10"));
        stockIn(s, branch, sku, 20, "10");

        // đếm thiếu: 20 -> 17
        JsonNode st = post("/api/stocktakes", s, m("branchId", branch, "note", "Kiểm kê tháng"), 201);
        String id = st.get("id").asText();
        assertThat(st.get("code").asText()).startsWith("KK-");
        assertThat(st.get("status").asText()).isEqualTo("IN_PROGRESS");
        JsonNode counted = count(s, id, sku, 17);
        assertThat(counted.get("items").get(0).get("differenceQty").decimalValue()).isEqualByComparingTo("-3");
        assertThat(onHand(s, branch, sku)).isEqualTo(20);                 // chưa hoàn tất thì chưa đổi tồn

        JsonNode done = post("/api/stocktakes/" + id + "/complete", s, null, 200);
        assertThat(done.get("status").asText()).isEqualTo("COMPLETED");
        assertThat(done.get("items").get(0).get("systemQty").decimalValue()).isEqualByComparingTo("20");
        assertThat(done.get("items").get(0).get("actualQty").decimalValue()).isEqualByComparingTo("17");
        assertThat(done.get("items").get(0).get("differenceQty").decimalValue()).isEqualByComparingTo("-3");
        assertThat(onHand(s, branch, sku)).isEqualTo(17);
        post("/api/stocktakes/" + id + "/complete", s, null, 409);        // không hoàn tất 2 lần

        // đếm thừa: 17 -> 25
        String id2 = post("/api/stocktakes", s, m("branchId", branch), 201).get("id").asText();
        count(s, id2, sku, 25);
        post("/api/stocktakes/" + id2 + "/complete", s, null, 200);
        assertThat(onHand(s, branch, sku)).isEqualTo(25);

        // ledger có đúng 2 bút toán STOCKTAKE_ADJUST: OUT 3 và IN 8
        BigDecimal adjOut = BigDecimal.ZERO, adjIn = BigDecimal.ZERO;
        for (JsonNode r : get("/api/inventory/ledger?skuId=" + sku + "&size=50", s).get("content")) {
            if (!r.get("referenceType").asText().equals("STOCKTAKE_ADJUST")) continue;
            if (r.get("type").asText().equals("OUT")) adjOut = adjOut.add(r.get("quantity").decimalValue());
            else adjIn = adjIn.add(r.get("quantity").decimalValue());
        }
        assertThat(adjOut).isEqualByComparingTo("3");
        assertThat(adjIn).isEqualByComparingTo("8");
    }

    @Test
    void stocktakeWithNoDifferenceWritesNoLedgerAndEmptyCannotComplete() throws Exception {
        Session s = registerTenant();
        UUID branch = createBranch(s, "A");
        UUID sku = firstSkuId(createProduct(s, "Hàng", "ST-2", "10"));
        stockIn(s, branch, sku, 10, "10");

        String id = post("/api/stocktakes", s, m("branchId", branch), 201).get("id").asText();
        post("/api/stocktakes/" + id + "/complete", s, null, 400);        // chưa đếm gì

        count(s, id, sku, 10);
        post("/api/stocktakes/" + id + "/complete", s, null, 200);
        assertThat(get("/api/inventory/ledger?skuId=" + sku, s).get("totalElements").asInt()).isEqualTo(1); // chỉ có dòng nhập
    }

    @Test
    void inProgressStocktakeCanBeDiscardedButCompletedCannot() throws Exception {
        Session s = registerTenant();
        UUID branch = createBranch(s, "A");
        UUID sku = firstSkuId(createProduct(s, "Hàng", "ST-3", "10"));
        stockIn(s, branch, sku, 10, "10");

        String draft = post("/api/stocktakes", s, m("branchId", branch), 201).get("id").asText();
        count(s, draft, sku, 3);
        send(HttpMethod.DELETE, "/api/stocktakes/" + draft, s, null, 204);
        send(HttpMethod.GET, "/api/stocktakes/" + draft, s, null, 404);
        assertThat(onHand(s, branch, sku)).isEqualTo(10);                 // bỏ phiên không đổi tồn

        String done = post("/api/stocktakes", s, m("branchId", branch), 201).get("id").asText();
        count(s, done, sku, 10);
        post("/api/stocktakes/" + done + "/complete", s, null, 200);
        send(HttpMethod.DELETE, "/api/stocktakes/" + done, s, null, 409);
    }

    @Test
    void lowStockFilterUsesReorderThresholdOnSku() throws Exception {
        Session s = registerTenant();
        UUID branch = createBranch(s, "A");
        UUID sku = firstSkuId(createProduct(s, "Hàng", "LOW-1", "10"));
        stockIn(s, branch, sku, 8, "10");

        assertThat(get("/api/inventory/stock?lowStockOnly=true", s).get("totalElements").asInt()).isZero();
        put("/api/variants/" + sku + "/reorder-threshold", s, m("reorderThreshold", 10), 200);   // available 8 <= 10
        JsonNode low = get("/api/inventory/stock?lowStockOnly=true", s);
        assertThat(low.get("totalElements").asInt()).isEqualTo(1);
        assertThat(low.get("content").get(0).get("lowStock").asBoolean()).isTrue();
        assertThat(low.get("content").get(0).get("skuCode").asText()).isEqualTo("LOW-1");
        assertThat(stockRow(s, branch, sku).get("available").decimalValue()).isEqualByComparingTo("8");
        assertThat(stockRow(s, branch, sku).get("reorderThreshold").decimalValue()).isEqualByComparingTo("10");

        // nhập thêm cho vượt ngưỡng => không còn trong danh sách cảnh báo
        stockIn(s, branch, sku, 5, "10");
        assertThat(get("/api/inventory/stock?lowStockOnly=true", s).get("totalElements").asInt()).isZero();
    }
}
