package com.oism.catalog;

import com.fasterxml.jackson.databind.JsonNode;
import com.oism.support.IntegrationTestBase;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/** FR-INV-02 + FR-COST-01. */
class PurchaseCostIT extends IntegrationTestBase {

    @Test
    void weightedAverageCostAcrossReceiptsAndBranches() throws Exception {
        Session s = registerTenant();
        UUID b1 = createBranch(s, "B1");
        UUID b2 = createBranch(s, "B2");
        JsonNode p = createProduct(s, "Hàng", "COST-1", "500");
        UUID sku = firstSkuId(p);

        stockIn(s, b1, sku, 10, "100");
        assertThat(avgCost(s, p)).isEqualByComparingTo("100");

        // nhập 10 @ 200 vào CHI NHÁNH KHÁC: tồn cũ tính trên tổng mọi chi nhánh => (10*100+10*200)/20 = 150
        stockIn(s, b2, sku, 10, "200");
        assertThat(avgCost(s, p)).isEqualByComparingTo("150");

        // lô thứ 3: 20 @ 300 => (20*150 + 20*300)/40 = 225
        stockIn(s, b1, sku, 20, "300");
        assertThat(avgCost(s, p)).isEqualByComparingTo("225");

        assertThat(onHand(s, b1, sku)).isEqualTo(30);
        assertThat(onHand(s, b2, sku)).isEqualTo(10);

        // ledger: 3 dòng IN / PURCHASE_RECEIPT, balanceAfter đúng theo từng chi nhánh
        JsonNode ledger = get("/api/inventory/ledger?skuId=" + sku, s);
        assertThat(ledger.get("totalElements").asInt()).isEqualTo(3);
        for (JsonNode row : ledger.get("content")) {
            assertThat(row.get("type").asText()).isEqualTo("IN");
            assertThat(row.get("referenceType").asText()).isEqualTo("PURCHASE_RECEIPT");
            assertThat(row.get("referenceId").asText()).isNotBlank();
        }
        JsonNode newest = ledger.get("content").get(0);   // mới nhất trước
        assertThat(newest.get("quantity").decimalValue()).isEqualByComparingTo("20");
        assertThat(newest.get("balanceAfter").decimalValue()).isEqualByComparingTo("30");
        assertThat(newest.get("unitCost").decimalValue()).isEqualByComparingTo("300");
    }

    @Test
    void decimalQuantitiesAreSupported() throws Exception {
        Session s = registerTenant();
        UUID branch = createBranch(s, "B1");
        JsonNode p = createProduct(s, "Gạo (kg)", "RICE-1", "30000");
        UUID sku = firstSkuId(p);

        stockIn(s, branch, sku, "2.5", "100");
        stockIn(s, branch, sku, "2.5", "200");

        assertThat(onHandDecimal(s, branch, sku)).isEqualByComparingTo("5");
        assertThat(avgCost(s, p)).isEqualByComparingTo("150");
        // quá 3 chữ số thập phân => 400
        post("/api/purchase-receipts", s, m("branchId", branch, "supplierId", defaultSupplier(s), "items",
                List.of(m("skuId", sku, "quantity", new BigDecimal("1.2345"), "unitPrice", 1))), 400);
    }

    @Test
    void receiptLifecycleRules() throws Exception {
        Session s = registerTenant();
        UUID branch = createBranch(s, "B1");
        UUID sku = firstSkuId(createProduct(s, "Hàng", "LIFE-1", "10"));

        JsonNode draft = createReceipt(s, branch, sku, "5", "12.5");
        assertThat(draft.get("status").asText()).isEqualTo("DRAFT");
        assertThat(draft.get("code").asText()).startsWith("PN-");
        assertThat(draft.get("receiptDate").asText()).isNotBlank();
        assertThat(draft.get("totalAmount").decimalValue()).isEqualByComparingTo("62.5");
        // DRAFT chưa làm thay đổi tồn kho
        assertThat(onHand(s, branch, sku)).isZero();

        String id = draft.get("id").asText();
        assertThat(post("/api/purchase-receipts/" + id + "/confirm", s, null, 200).get("status").asText()).isEqualTo("CONFIRMED");
        assertThat(onHand(s, branch, sku)).isEqualTo(5);

        // xác nhận lần 2 / huỷ phiếu đã xác nhận => 409, tồn kho không đổi (chống nhập trùng)
        post("/api/purchase-receipts/" + id + "/confirm", s, null, 409);
        post("/api/purchase-receipts/" + id + "/cancel", s, null, 409);
        assertThat(onHand(s, branch, sku)).isEqualTo(5);

        // phiếu DRAFT huỷ được; huỷ rồi không xác nhận được nữa
        JsonNode d2 = createReceipt(s, branch, sku, "1", "1");
        String id2 = d2.get("id").asText();
        post("/api/purchase-receipts/" + id2 + "/cancel", s, null, 200);
        post("/api/purchase-receipts/" + id2 + "/confirm", s, null, 409);
        assertThat(d2.get("code").asText()).isNotEqualTo(draft.get("code").asText());
    }

    @Test
    void validationRejectsBadReceipts() throws Exception {
        Session s = registerTenant();
        UUID branch = createBranch(s, "B1");
        UUID sku = firstSkuId(createProduct(s, "Hàng", "VAL-1", "10"));
        UUID supplier = defaultSupplier(s);

        post("/api/purchase-receipts", s, m("branchId", branch, "supplierId", supplier, "items",
                List.of(m("skuId", sku, "quantity", 0, "unitPrice", 1))), 400);          // qty = 0
        post("/api/purchase-receipts", s, m("branchId", branch, "supplierId", supplier, "items",
                List.of(m("skuId", sku, "quantity", 1, "unitPrice", -1))), 400);         // giá âm
        post("/api/purchase-receipts", s, m("branchId", branch, "supplierId", supplier, "items", List.of()), 400);
        post("/api/purchase-receipts", s, m("branchId", branch, "items",
                List.of(m("skuId", sku, "quantity", 1, "unitPrice", 1))), 400);          // thiếu supplierId (bắt buộc)
        post("/api/purchase-receipts", s, m("branchId", branch, "supplierId", supplier, "items",
                List.of(m("skuId", UUID.randomUUID(), "quantity", 1, "unitPrice", 1))), 404);   // SKU không tồn tại
        post("/api/purchase-receipts", s, m("branchId", branch, "supplierId", UUID.randomUUID(), "items",
                List.of(m("skuId", sku, "quantity", 1, "unitPrice", 1))), 404);          // NCC không tồn tại
    }

    @Test
    void costIsRecomputedFromAllStockNotJustLastLot() throws Exception {
        Session s = registerTenant();
        UUID branch = createBranch(s, "B1");
        JsonNode p = createProduct(s, "Hàng", "HIST-1", "10");
        UUID sku = firstSkuId(p);
        stockIn(s, branch, sku, 4, "10");
        stockIn(s, branch, sku, 4, "20");
        // giá vốn cuối = (4*10 + 4*20)/8 = 15
        assertThat(avgCost(s, p)).isEqualByComparingTo("15");
        assertThat(get("/api/products/" + p.get("id").asText(), s).get("variants").get(0)
                .get("retailPrice").decimalValue()).isEqualByComparingTo(new BigDecimal("10"));   // giá bán không bị đụng
    }
}
