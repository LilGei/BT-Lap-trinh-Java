package com.oism.support;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Mỗi test tự đăng ký 1 tenant mới (domain ngẫu nhiên) nên không cần dọn dữ liệu:
 * ledger là append-only (kể cả TRUNCATE) nên cũng không thể dọn. Muốn sạch: DROP DATABASE oism_test.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
public abstract class IntegrationTestBase {
    private static final Map<UUID, UUID> SUPPLIERS = new ConcurrentHashMap<>();

    @Autowired protected MockMvc mvc;
    @Autowired protected ObjectMapper json;

    public record Session(String token, UUID tenantId) {}

    /** Dựng JSON body: m("a", 1, "b", "x"). Dùng thay Map.of để khỏi vướng suy luận kiểu generic. */
    protected static Map<String, Object> m(Object... kv) {
        Map<String, Object> map = new LinkedHashMap<>();
        for (int i = 0; i < kv.length; i += 2) map.put((String) kv[i], kv[i + 1]);
        return map;
    }

    protected JsonNode send(HttpMethod method, String url, Session s, Object body, int expectedStatus) throws Exception {
        MockHttpServletRequestBuilder b = MockMvcRequestBuilders.request(method, url);
        if (s != null) b.header("Authorization", "Bearer " + s.token());
        if (body != null) b.contentType(MediaType.APPLICATION_JSON).content(json.writeValueAsString(body));
        MvcResult r = mvc.perform(b).andExpect(status().is(expectedStatus)).andReturn();
        String content = r.getResponse().getContentAsString();
        return content.isBlank() ? json.createObjectNode() : json.readTree(content);
    }

    protected JsonNode get(String url, Session s) throws Exception { return send(HttpMethod.GET, url, s, null, 200); }
    protected JsonNode post(String url, Session s, Object body, int expected) throws Exception {
        return send(HttpMethod.POST, url, s, body, expected);
    }
    protected JsonNode put(String url, Session s, Object body, int expected) throws Exception {
        return send(HttpMethod.PUT, url, s, body, expected);
    }

    protected static String randomDomain() { return "t" + UUID.randomUUID().toString().replace("-", "").substring(0, 12); }

    protected Session registerTenant() throws Exception {
        String domain = randomDomain();
        JsonNode n = post("/api/auth/register-tenant", null, m(
                "domain", domain, "storeName", "Store " + domain, "ownerName", "Owner",
                "email", domain + "@test.vn", "password", "12345678"), 201);
        return new Session(n.get("accessToken").asText(), UUID.fromString(n.get("tenantId").asText()));
    }

    /** Owner tạo user với vai trò (STAFF/CASHIER) rồi đăng nhập để lấy token của user đó. */
    protected Session createUserAndLogin(Session owner, String role) throws Exception {
        String email = role.toLowerCase() + UUID.randomUUID().toString().substring(0, 8) + "@test.vn";
        post("/api/users", owner, m("fullName", role + " user", "email", email,
                "password", "12345678", "role", role), 201);
        JsonNode n = post("/api/auth/login", null, m("identifier", email, "password", "12345678"), 200);
        return new Session(n.get("accessToken").asText(), owner.tenantId());
    }

    protected UUID createBranch(Session s, String code) throws Exception {
        JsonNode n = post("/api/branches", s, m("code", code, "name", "Branch " + code, "type", "STORE"), 201);
        return UUID.fromString(n.get("id").asText());
    }

    protected JsonNode createProduct(Session s, String name, String sku, String price) throws Exception {
        return post("/api/products", s, m("name", name,
                "variants", List.of(m("skuCode", sku, "retailPrice", new BigDecimal(price)))), 201);
    }

    protected UUID firstSkuId(JsonNode product) {
        return UUID.fromString(product.get("variants").get(0).get("id").asText());
    }

    /** Mỗi tenant có 1 nhà cung cấp mặc định (supplierId bắt buộc trên phiếu nhập). */
    protected UUID defaultSupplier(Session s) throws Exception {
        UUID cached = SUPPLIERS.get(s.tenantId());
        if (cached != null) return cached;
        JsonNode n = post("/api/suppliers", s, m("name", "NCC mặc định", "phone", "0900000000"), 201);
        UUID id = UUID.fromString(n.get("id").asText());
        SUPPLIERS.put(s.tenantId(), id);
        return id;
    }

    protected JsonNode createReceipt(Session s, UUID branchId, UUID skuId, String qty, String price) throws Exception {
        return post("/api/purchase-receipts", s, m("branchId", branchId, "supplierId", defaultSupplier(s),
                "items", List.of(m("skuId", skuId, "quantity", new BigDecimal(qty), "unitPrice", new BigDecimal(price)))), 201);
    }

    /** Tạo + xác nhận phiếu nhập 1 dòng. */
    protected JsonNode stockIn(Session s, UUID branchId, UUID skuId, int qty, String price) throws Exception {
        return stockIn(s, branchId, skuId, String.valueOf(qty), price);
    }

    protected JsonNode stockIn(Session s, UUID branchId, UUID skuId, String qty, String price) throws Exception {
        JsonNode receipt = createReceipt(s, branchId, skuId, qty, price);
        return post("/api/purchase-receipts/" + receipt.get("id").asText() + "/confirm", s, null, 200);
    }

    protected int onHand(Session s, UUID branchId, UUID skuId) throws Exception {
        return onHandDecimal(s, branchId, skuId).intValue();
    }

    protected BigDecimal onHandDecimal(Session s, UUID branchId, UUID skuId) throws Exception {
        JsonNode content = get("/api/inventory/stock?branchId=" + branchId + "&skuId=" + skuId, s).get("content");
        return content.isEmpty() ? BigDecimal.ZERO : content.get(0).get("onHand").decimalValue();
    }

    protected JsonNode stockRow(Session s, UUID branchId, UUID skuId) throws Exception {
        return get("/api/inventory/stock?branchId=" + branchId + "&skuId=" + skuId, s).get("content").get(0);
    }

    protected BigDecimal avgCost(Session s, JsonNode product) throws Exception {
        return get("/api/products/" + product.get("id").asText(), s).get("variants").get(0)
                .get("currentAverageCost").decimalValue();
    }
}
