package com.oism.catalog;

import com.oism.support.IntegrationTestBase;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/** NFR-SEC-03 + NFR-PERF-02: database tự bảo vệ, kể cả khi code ứng dụng có lỗi. */
class LedgerIntegrityIT extends IntegrationTestBase {
    @Autowired JdbcTemplate jdbc;

    @Test
    void ledgerRejectsUpdateAndDelete() throws Exception {
        Session s = registerTenant();
        UUID branch = createBranch(s, "B1");
        UUID sku = firstSkuId(createProduct(s, "Hàng", "LED-1", "10"));
        stockIn(s, branch, sku, 5, "10");

        assertThatThrownBy(() -> jdbc.update("UPDATE inventory_transactions SET quantity = 99 WHERE tenant_id = ?", s.tenantId()))
                .isInstanceOf(DataAccessException.class).hasMessageContaining("append-only");
        assertThatThrownBy(() -> jdbc.update("DELETE FROM inventory_transactions WHERE tenant_id = ?", s.tenantId()))
                .isInstanceOf(DataAccessException.class).hasMessageContaining("append-only");

        Integer rows = jdbc.queryForObject("SELECT count(*) FROM inventory_transactions WHERE tenant_id = ?",
                Integer.class, s.tenantId());
        assertThat(rows).isEqualTo(1);
    }

    @Test
    void costHistoryIsAlsoAppendOnly() throws Exception {
        Session s = registerTenant();
        UUID branch = createBranch(s, "B1");
        UUID sku = firstSkuId(createProduct(s, "Hàng", "LED-2", "10"));
        stockIn(s, branch, sku, 5, "10");

        assertThatThrownBy(() -> jdbc.update("UPDATE cost_history SET new_cost = 1 WHERE tenant_id = ?", s.tenantId()))
                .isInstanceOf(DataAccessException.class).hasMessageContaining("append-only");
    }

    @Test
    void stockBalancesCheckConstraintsBlockNegativeAvailable() throws Exception {
        Session s = registerTenant();
        UUID branch = createBranch(s, "B1");
        UUID sku = firstSkuId(createProduct(s, "Hàng", "LED-3", "10"));
        stockIn(s, branch, sku, 5, "10");

        // reserved > on_hand => available âm => DB từ chối
        assertThatThrownBy(() -> jdbc.update("UPDATE stock_balances SET reserved = on_hand + 1 WHERE tenant_id = ?", s.tenantId()))
                .isInstanceOf(DataAccessException.class);
        // on_hand âm => DB từ chối
        assertThatThrownBy(() -> jdbc.update("UPDATE stock_balances SET on_hand = -1 WHERE tenant_id = ?", s.tenantId()))
                .isInstanceOf(DataAccessException.class);
        assertThat(onHand(s, branch, sku)).isEqualTo(5);
    }
}
