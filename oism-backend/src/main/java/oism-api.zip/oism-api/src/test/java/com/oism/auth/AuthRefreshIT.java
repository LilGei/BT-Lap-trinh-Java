package com.oism.auth;

import com.fasterxml.jackson.databind.JsonNode;
import com.oism.support.IntegrationTestBase;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/** FR-AUTH-01..04 + NFR-SEC-01: refresh token xoay vòng, đăng xuất, khoá user/tenant, user làm việc ở nhiều chi nhánh. */
class AuthRefreshIT extends IntegrationTestBase {
    @Autowired JdbcTemplate jdbc;

    private record Registered(String domain, String email, JsonNode body) {}

    private Registered register() throws Exception {
        String domain = randomDomain();
        String email = domain + "@test.vn";
        JsonNode n = post("/api/auth/register-tenant", null, m("domain", domain, "storeName", "S", "ownerName", "O",
                "email", email, "password", "12345678"), 201);
        return new Registered(domain, email, n);
    }

    private Session session(JsonNode auth) {
        return new Session(auth.get("accessToken").asText(), UUID.fromString(auth.get("tenantId").asText()));
    }

    @Test
    void registerReturnsOwnerTokensAndRefreshRotates() throws Exception {
        Registered r = register();
        assertThat(r.body().get("role").asText()).isEqualTo("OWNER");
        assertThat(r.body().get("tokenType").asText()).isEqualTo("Bearer");
        String refresh1 = r.body().get("refreshToken").asText();
        assertThat(refresh1).hasSizeGreaterThan(30);

        JsonNode second = post("/api/auth/refresh", null, m("refreshToken", refresh1), 200);
        String refresh2 = second.get("refreshToken").asText();
        assertThat(refresh2).isNotEqualTo(refresh1);
        // access token mới dùng được
        get("/api/branches", session(second));
        // refresh token cũ đã bị thu hồi (xoay vòng) => 401; token mới vẫn dùng được 1 lần
        post("/api/auth/refresh", null, m("refreshToken", refresh1), 401);
        post("/api/auth/refresh", null, m("refreshToken", refresh2), 200);
        // token rác => 401
        post("/api/auth/refresh", null, m("refreshToken", "khong-phai-token"), 401);
    }

    @Test
    void refreshTokenIsStoredHashedNotPlain() throws Exception {
        Registered r = register();
        String raw = r.body().get("refreshToken").asText();
        UUID tenant = UUID.fromString(r.body().get("tenantId").asText());
        Integer plain = jdbc.queryForObject("SELECT count(*) FROM refresh_tokens WHERE token_hash = ?", Integer.class, raw);
        Integer rows = jdbc.queryForObject("SELECT count(*) FROM refresh_tokens WHERE tenant_id = ?", Integer.class, tenant);
        assertThat(plain).isZero();
        assertThat(rows).isEqualTo(1);
    }

    @Test
    void logoutRevokesRefreshTokenAndIsIdempotent() throws Exception {
        Registered r = register();
        String refresh = r.body().get("refreshToken").asText();

        post("/api/auth/logout", null, m("refreshToken", refresh), 204);
        post("/api/auth/refresh", null, m("refreshToken", refresh), 401);
        post("/api/auth/logout", null, m("refreshToken", refresh), 204);                   // gọi lại vẫn OK
        post("/api/auth/logout", null, m("refreshToken", "token-la-khong-ton-tai"), 204);   // token lạ vẫn OK
    }

    @Test
    void wrongPasswordIs401() throws Exception {
        Registered r = register();
        post("/api/auth/login", null, m("identifier", r.email(), "password", "sai-mat-khau"), 401);
        post("/api/auth/login", null, m("identifier", "khong-ton-tai@test.vn", "password", "12345678"), 401);
        post("/api/auth/login", null, m("identifier", r.email().toUpperCase(), "password", "12345678"), 200);   // email không phân biệt hoa/thường
    }

    @Test
    void suspendedTenantCannotLoginOrRefresh() throws Exception {
        Registered r = register();
        UUID tenant = UUID.fromString(r.body().get("tenantId").asText());
        String refresh = r.body().get("refreshToken").asText();

        jdbc.update("UPDATE tenants SET status = 'SUSPENDED' WHERE id = ?", tenant);
        post("/api/auth/login", null, m("identifier", r.email(), "password", "12345678"), 403);
        post("/api/auth/refresh", null, m("refreshToken", refresh), 403);

        jdbc.update("UPDATE tenants SET status = 'ACTIVE' WHERE id = ?", tenant);
        post("/api/auth/login", null, m("identifier", r.email(), "password", "12345678"), 200);
    }

    @Test
    void lockedUserCannotLoginUntilReactivated() throws Exception {
        Session owner = registerTenant();
        String email = "locked" + UUID.randomUUID().toString().substring(0, 8) + "@test.vn";
        JsonNode created = post("/api/users", owner, m("fullName", "Thu ngân", "email", email,
                "password", "12345678", "role", "CASHIER"), 201);
        String userId = created.get("id").asText();
        assertThat(created.get("status").asText()).isEqualTo("ACTIVE");
        assertThat(created.get("role").asText()).isEqualTo("CASHIER");

        send(HttpMethod.PATCH, "/api/users/" + userId + "/status?value=LOCKED", owner, null, 200);
        post("/api/auth/login", null, m("identifier", email, "password", "12345678"), 403);
        send(HttpMethod.PATCH, "/api/users/" + userId + "/status?value=INACTIVE", owner, null, 200);
        post("/api/auth/login", null, m("identifier", email, "password", "12345678"), 403);
        send(HttpMethod.PATCH, "/api/users/" + userId + "/status?value=ACTIVE", owner, null, 200);
        post("/api/auth/login", null, m("identifier", email, "password", "12345678"), 200);

        // Owner không tự khoá mình
        String ownerId = null;
        for (JsonNode u : get("/api/users", owner)) if (u.get("role").asText().equals("OWNER")) ownerId = u.get("id").asText();
        send(HttpMethod.PATCH, "/api/users/" + ownerId + "/status?value=LOCKED", owner, null, 400);
    }

    @Test
    void userCanWorkAtManyBranches() throws Exception {
        Session owner = registerTenant();
        UUID b1 = createBranch(owner, "B1");
        UUID b2 = createBranch(owner, "B2");
        String email = "multi" + UUID.randomUUID().toString().substring(0, 8) + "@test.vn";

        JsonNode u = post("/api/users", owner, m("fullName", "Nhân viên", "email", email, "password", "12345678",
                "role", "STAFF", "branchIds", List.of(b1, b2)), 201);
        String id = u.get("id").asText();
        assertThat(u.get("branchIds")).hasSize(2);

        JsonNode listed = null;
        for (JsonNode x : get("/api/users", owner)) if (x.get("id").asText().equals(id)) listed = x;
        assertThat(listed.get("branchIds")).hasSize(2);

        // thay danh sách chi nhánh
        assertThat(put("/api/users/" + id + "/branches", owner, m("branchIds", List.of(b1)), 200).get("branchIds")).hasSize(1);
        assertThat(put("/api/users/" + id + "/branches", owner, m("branchIds", List.of()), 200).get("branchIds")).isEmpty();
        // chi nhánh không tồn tại / của tenant khác => 404
        Session other = registerTenant();
        UUID foreign = createBranch(other, "X1");
        put("/api/users/" + id + "/branches", owner, m("branchIds", List.of(foreign)), 404);
        // tenant khác không đụng được user này
        send(HttpMethod.PATCH, "/api/users/" + id + "/status?value=LOCKED", other, null, 404);
    }

    @Test
    void ownerAccountsCannotBeCreatedThroughUserApiAndDuplicatesRejected() throws Exception {
        Session owner = registerTenant();
        post("/api/users", owner, m("fullName", "X", "email", "x1@test.vn", "password", "12345678", "role", "OWNER"), 400);
        post("/api/users", owner, m("fullName", "X", "password", "12345678", "role", "STAFF"), 400);   // thiếu email và phone
        String email = "dup" + UUID.randomUUID().toString().substring(0, 8) + "@test.vn";
        post("/api/users", owner, m("fullName", "A", "email", email, "password", "12345678", "role", "STAFF"), 201);
        post("/api/users", owner, m("fullName", "B", "email", email.toUpperCase(), "password", "12345678", "role", "STAFF"), 409);
    }

    @Test
    void domainMustBeUnique() throws Exception {
        Registered r = register();
        post("/api/auth/register-tenant", null, m("domain", r.domain().toUpperCase(), "storeName", "S", "ownerName", "O",
                "email", "other" + r.email(), "password", "12345678"), 409);
    }
}
