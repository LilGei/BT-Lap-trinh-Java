package com.oism.catalog;

import com.oism.common.InsufficientStockException;
import com.oism.inventory.InventoryService;
import com.oism.inventory.InventoryTransaction.ReferenceType;
import com.oism.support.IntegrationTestBase;
import com.oism.tenant.TenantContext;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;

/** NFR-PERF-02: Flash Sale. N request đồng thời vào ít hàng => không bao giờ bán lố. */
class AntiOversellConcurrencyIT extends IntegrationTestBase {
    @Autowired InventoryService inventory;
    @Autowired PlatformTransactionManager tm;

    /** @return {thành công, bị từ chối do hết hàng, lỗi khác} */
    private int[] hammer(Session s, UUID branch, UUID sku, int threads) throws Exception {
        TransactionTemplate tx = new TransactionTemplate(tm);
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch ready = new CountDownLatch(threads);
        CountDownLatch go = new CountDownLatch(1);
        AtomicInteger ok = new AtomicInteger(), rejected = new AtomicInteger(), other = new AtomicInteger();
        List<Future<Object>> futures = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            futures.add(pool.submit(() -> {
                TenantContext.set(s.tenantId());
                try {
                    ready.countDown();
                    go.await();
                    tx.executeWithoutResult(st -> inventory.reserve(branch, sku, BigDecimal.ONE));
                    ok.incrementAndGet();
                } catch (InsufficientStockException e) {
                    rejected.incrementAndGet();
                } catch (Exception e) {
                    e.printStackTrace();
                    other.incrementAndGet();
                } finally {
                    TenantContext.clear();
                }
                return null;
            }));
        }
        ready.await();
        go.countDown();
        for (Future<Object> f : futures) f.get(60, TimeUnit.SECONDS);
        pool.shutdown();
        return new int[]{ok.get(), rejected.get(), other.get()};
    }

    @Test
    void fiftyBuyersOneItemLeft() throws Exception {
        Session s = registerTenant();
        UUID branch = createBranch(s, "A");
        UUID sku = firstSkuId(createProduct(s, "Flash", "FLASH-1", "10"));
        stockIn(s, branch, sku, 1, "5");

        int[] r = hammer(s, branch, sku, 50);

        assertThat(r[0]).as("đúng 1 đơn giữ được hàng").isEqualTo(1);
        assertThat(r[1]).as("49 đơn bị từ chối").isEqualTo(49);
        assertThat(r[2]).as("không có lỗi bất ngờ").isZero();
        var row = stockRow(s, branch, sku);
        assertThat(row.get("onHand").decimalValue()).isEqualByComparingTo("1");
        assertThat(row.get("reserved").decimalValue()).isEqualByComparingTo("1");
        assertThat(row.get("available").decimalValue()).isEqualByComparingTo("0");   // không bao giờ âm
    }

    @Test
    void fiftyBuyersTenItemsLeft() throws Exception {
        Session s = registerTenant();
        UUID branch = createBranch(s, "A");
        UUID sku = firstSkuId(createProduct(s, "Flash", "FLASH-10", "10"));
        stockIn(s, branch, sku, 10, "5");

        int[] r = hammer(s, branch, sku, 50);

        assertThat(r[0]).isEqualTo(10);
        assertThat(r[1]).isEqualTo(40);
        assertThat(r[2]).isZero();
        var row = stockRow(s, branch, sku);
        assertThat(row.get("reserved").decimalValue()).isEqualByComparingTo("10");
        assertThat(row.get("available").decimalValue()).isEqualByComparingTo("0");
    }

    @Test
    void reserveThenCancelReleasesAndConfirmDeductsWithLedger() throws Exception {
        Session s = registerTenant();
        UUID branch = createBranch(s, "A");
        UUID sku = firstSkuId(createProduct(s, "Hàng", "RSV-1", "10"));
        stockIn(s, branch, sku, 5, "5");
        TransactionTemplate tx = new TransactionTemplate(tm);

        TenantContext.set(s.tenantId());
        try {
            tx.executeWithoutResult(st -> inventory.reserve(branch, sku, BigDecimal.valueOf(3)));
            assertThat(stockRow(s, branch, sku).get("available").decimalValue()).isEqualByComparingTo("2");

            tx.executeWithoutResult(st -> inventory.release(branch, sku, BigDecimal.valueOf(3)));       // Cancelled
            assertThat(stockRow(s, branch, sku).get("available").decimalValue()).isEqualByComparingTo("5");

            tx.executeWithoutResult(st -> inventory.reserve(branch, sku, BigDecimal.valueOf(2)));
            tx.executeWithoutResult(st -> inventory.deductReserved(branch, sku, BigDecimal.valueOf(2),
                    ReferenceType.SALE, UUID.randomUUID(), null));                                       // Confirmed
        } finally {
            TenantContext.clear();
        }
        var row = stockRow(s, branch, sku);
        assertThat(row.get("onHand").decimalValue()).isEqualByComparingTo("3");
        assertThat(row.get("reserved").decimalValue()).isEqualByComparingTo("0");
        var ledger = get("/api/inventory/ledger?skuId=" + sku, s).get("content");
        assertThat(ledger.get(0).get("referenceType").asText()).isEqualTo("SALE");
        assertThat(ledger.get(0).get("type").asText()).isEqualTo("OUT");
        assertThat(ledger.get(0).get("balanceAfter").decimalValue()).isEqualByComparingTo("3");
    }
}
