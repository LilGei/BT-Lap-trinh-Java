package com.oism.catalog;

import com.fasterxml.jackson.databind.JsonNode;
import com.oism.support.IntegrationTestBase;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/** NFR-TENANT-01: dữ liệu của tenant này tuyệt đối không lọt sang tenant khác. */
class TenantIsolationIT extends IntegrationTestBase {

    @Test
    void tenantBCannotSeeOrTouchTenantAData() throws Exception {
        Session a = registerTenant();
        Session b = registerTenant();

        UUID branchA = createBranch(a, "A01");
        JsonNode productA = createProduct(a, "Hàng của A", "SHARED-SKU", "100");
        UUID skuA = firstSkuId(productA);
        stockIn(a, branchA, skuA, 5, "10");
        UUID supplierA = defaultSupplier(a);

        // B không thấy sản phẩm / biến thể / tồn kho / sổ cái / người dùng của A
        send(HttpMethod.GET, "/api/products/" + productA.get("id").asText(), b, null, 404);
        assertThat(get("/api/products", b).get("totalElements").asInt()).isZero();
        assertThat(get("/api/variants/search?q=SHARED", b).get("totalElements").asInt()).isZero();
        assertThat(get("/api/branches", b)).isEmpty();
        assertThat(get("/api/suppliers", b)).isEmpty();
        assertThat(get("/api/inventory/stock", b).get("totalElements").asInt()).isZero();
        assertThat(get("/api/inventory/ledger", b).get("totalElements").asInt()).isZero();
        assertThat(get("/api/users", b)).hasSize(1);   // chỉ chủ cửa hàng B

        // B không thể dùng chi nhánh / SKU / nhà cung cấp của A để tạo phiếu nhập
        UUID branchB = createBranch(b, "B01");
        UUID supplierB = defaultSupplier(b);
        post("/api/purchase-receipts", b, m("branchId", branchA, "supplierId", supplierB, "items",
                List.of(m("skuId", skuA, "quantity", 1, "unitPrice", 1))), 404);
        post("/api/purchase-receipts", b, m("branchId", branchB, "supplierId", supplierB, "items",
                List.of(m("skuId", skuA, "quantity", 1, "unitPrice", 1))), 404);
        UUID skuB0 = firstSkuId(createProduct(b, "Hàng B0", "B0-1", "1"));
        post("/api/purchase-receipts", b, m("branchId", branchB, "supplierId", supplierA, "items",
                List.of(m("skuId", skuB0, "quantity", 1, "unitPrice", 1))), 404);

        // B sửa giá / barcode SKU của A => 404
        put("/api/variants/" + skuA + "/prices", b, m("retailPrice", 1, "wholesalePrice", 1), 404);
        post("/api/variants/" + skuA + "/barcodes", b, m("code", "ABC-1"), 404);

        // Mỗi tenant được dùng chung mã SKU / mã chi nhánh / barcode (unique theo tenant)
        createProduct(b, "Hàng của B", "SHARED-SKU", "200");
        createBranch(b, "A01");
        post("/api/products", a, m("name", "A có barcode", "variants",
                List.of(m("skuCode", "BC-A", "retailPrice", 1, "barcode", "4006381333931"))), 201);
        post("/api/products", b, m("name", "B có barcode", "variants",
                List.of(m("skuCode", "BC-B", "retailPrice", 1, "barcode", "4006381333931"))), 201);
        // tra barcode chỉ ra SKU của đúng tenant mình
        assertThat(get("/api/variants/by-barcode/4006381333931", a).get("skuCode").asText()).isEqualTo("BC-A");
        assertThat(get("/api/variants/by-barcode/4006381333931", b).get("skuCode").asText()).isEqualTo("BC-B");

        // Dữ liệu của A không bị ảnh hưởng
        assertThat(get("/api/products", a).get("totalElements").asInt()).isEqualTo(2);
        assertThat(onHand(a, branchA, skuA)).isEqualTo(5);
    }
}
