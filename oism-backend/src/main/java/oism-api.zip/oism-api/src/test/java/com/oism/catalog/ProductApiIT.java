package com.oism.catalog;

import com.fasterxml.jackson.databind.JsonNode;
import com.oism.support.IntegrationTestBase;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

class ProductApiIT extends IntegrationTestBase {

    @Test
    void createProductWithVariantsAndRejectDuplicateSku() throws Exception {
        Session owner = registerTenant();
        JsonNode p = post("/api/products", owner, m("name", "Áo thun", "variants", List.of(
                m("skuCode", "AT-RED-M", "color", "Red", "size", "M", "retailPrice", 120000),
                m("skuCode", "AT-BLUE-L", "color", "Blue", "size", "L", "retailPrice", 125000, "wholesalePrice", 90000))), 201);

        assertThat(p.get("hasVariants").asBoolean()).isTrue();
        assertThat(p.get("variants")).hasSize(2);
        assertThat(p.get("categoryId").asText()).isNotBlank();
        JsonNode blue = p.get("variants").get(0).get("skuCode").asText().equals("AT-BLUE-L")
                ? p.get("variants").get(0) : p.get("variants").get(1);
        assertThat(blue.get("color").asText()).isEqualTo("Blue");
        assertThat(blue.get("size").asText()).isEqualTo("L");
        assertThat(blue.get("wholesalePrice").decimalValue()).isEqualByComparingTo("90000");

        // trùng SKU (không phân biệt hoa/thường) trong cùng tenant => 409
        post("/api/products", owner, m("name", "Khác", "variants",
                List.of(m("skuCode", "at-red-m", "retailPrice", 1))), 409);
        // trùng ngay trong 1 request => 409
        post("/api/products", owner, m("name", "Dup", "variants", List.of(
                m("skuCode", "X1", "retailPrice", 1), m("skuCode", "x1", "retailPrice", 1))), 409);
    }

    @Test
    void simpleProductHasNoVariantsFlag() throws Exception {
        Session owner = registerTenant();
        JsonNode p = createProduct(owner, "Nước suối", "NS-500", "5000");
        assertThat(p.get("hasVariants").asBoolean()).isFalse();
        assertThat(p.get("variants")).hasSize(1);
        assertThat(p.get("variants").get(0).get("currentAverageCost").decimalValue()).isEqualByComparingTo("0");
    }

    @Test
    void validationRejectsNegativePriceAndEmptyVariants() throws Exception {
        Session owner = registerTenant();
        post("/api/products", owner, m("name", "Bad", "variants",
                List.of(m("skuCode", "B1", "retailPrice", -5))), 400);
        post("/api/products", owner, m("name", "Bad", "variants", List.of()), 400);
    }

    @Test
    void blankSkuCodeIsGeneratedAndDefaultCategoryApplied() throws Exception {
        Session owner = registerTenant();
        JsonNode a = post("/api/products", owner, m("name", "A", "variants", List.of(m("retailPrice", 10))), 201);
        JsonNode b = post("/api/products", owner, m("name", "B", "variants", List.of(m("retailPrice", 10))), 201);

        String skuA = a.get("variants").get(0).get("skuCode").asText();
        String skuB = b.get("variants").get(0).get("skuCode").asText();
        assertThat(skuA).startsWith("SKU-");
        assertThat(skuB).startsWith("SKU-").isNotEqualTo(skuA);
        // categoryId bắt buộc: không truyền thì cùng vào danh mục mặc định
        assertThat(a.get("categoryId").asText()).isEqualTo(b.get("categoryId").asText());
        boolean found = false;
        for (JsonNode c : get("/api/categories", owner)) found |= c.get("name").asText().equals("Chưa phân loại");
        assertThat(found).isTrue();
    }

    @Test
    void autoBarcodeAtCreateIsValidEan13AndFindableByScan() throws Exception {
        Session owner = registerTenant();
        JsonNode p = post("/api/products", owner, m("name", "Bút", "variants",
                List.of(m("skuCode", "BUT-01", "retailPrice", 3000, "autoBarcode", true))), 201);
        JsonNode bc = p.get("variants").get(0).get("barcodes").get(0);

        assertThat(bc.get("type").asText()).isEqualTo("EAN13");
        assertThat(BarcodeUtil.isValidEan13(bc.get("code").asText())).isTrue();
        JsonNode found = get("/api/variants/by-barcode/" + bc.get("code").asText(), owner);
        assertThat(found.get("skuCode").asText()).isEqualTo("BUT-01");
    }

    @Test
    void variantCanHaveManyBarcodes() throws Exception {
        Session owner = registerTenant();
        JsonNode pa = createProduct(owner, "A", "A-1", "10");
        UUID a = firstSkuId(pa);
        UUID b = firstSkuId(createProduct(owner, "B", "B-1", "10"));

        // EAN-13 sai check digit => 400
        post("/api/variants/" + a + "/barcodes", owner, m("code", "4006381333932"), 400);
        // hợp lệ => EAN13
        JsonNode v1 = post("/api/variants/" + a + "/barcodes", owner, m("code", "4006381333931"), 201);
        assertThat(v1.get("barcodes")).hasSize(1);
        assertThat(v1.get("barcodes").get(0).get("type").asText()).isEqualTo("EAN13");
        // SKU khác hoặc chính SKU đó dùng lại cùng mã => 409
        post("/api/variants/" + b + "/barcodes", owner, m("code", "4006381333931"), 409);
        post("/api/variants/" + a + "/barcodes", owner, m("code", "4006381333931"), 409);
        // cùng SKU thêm mã thứ 2 (Code128) và mã tự sinh thứ 3
        JsonNode v2 = post("/api/variants/" + a + "/barcodes", owner, m("code", "ABC-123"), 201);
        assertThat(v2.get("barcodes")).hasSize(2);
        JsonNode v3 = post("/api/variants/" + a + "/barcodes/generate", owner, null, 201);
        assertThat(v3.get("barcodes")).hasSize(3);

        // xoá 1 mã => không tra cứu được nữa; các mã còn lại vẫn trỏ về SKU cũ
        String delId = null;
        for (JsonNode bc : v3.get("barcodes")) if (bc.get("code").asText().equals("ABC-123")) delId = bc.get("id").asText();
        send(HttpMethod.DELETE, "/api/variants/" + a + "/barcodes/" + delId, owner, null, 204);
        send(HttpMethod.GET, "/api/variants/by-barcode/ABC-123", owner, null, 404);
        assertThat(get("/api/variants/by-barcode/4006381333931", owner).get("id").asText()).isEqualTo(a.toString());
        assertThat(get("/api/products/" + pa.get("id").asText(), owner).get("variants").get(0).get("barcodes")).hasSize(2);
        // xoá barcode qua SKU không phải chủ => 404
        send(HttpMethod.DELETE, "/api/variants/" + b + "/barcodes/" + v3.get("barcodes").get(0).get("id").asText(), owner, null, 404);
    }

    @Test
    void ownerSetsPricesStaffSetsThresholdAndCostStaysSeparate() throws Exception {
        Session owner = registerTenant();
        Session staff = createUserAndLogin(owner, "STAFF");
        UUID sku = firstSkuId(createProduct(owner, "Giá", "G-1", "100"));

        JsonNode v = put("/api/variants/" + sku + "/prices", owner,
                m("retailPrice", new BigDecimal("150"), "wholesalePrice", new BigDecimal("120")), 200);
        assertThat(v.get("retailPrice").decimalValue()).isEqualByComparingTo("150");
        assertThat(v.get("wholesalePrice").decimalValue()).isEqualByComparingTo("120");
        assertThat(v.get("currentAverageCost").decimalValue()).isEqualByComparingTo("0");

        // giá niêm yết chỉ Owner (theo sơ đồ use case)
        put("/api/variants/" + sku + "/prices", staff, m("retailPrice", 1, "wholesalePrice", 1), 403);
        // ngưỡng cảnh báo tồn: Staff được
        JsonNode t = put("/api/variants/" + sku + "/reorder-threshold", staff, m("reorderThreshold", new BigDecimal("5")), 200);
        assertThat(t.get("reorderThreshold").decimalValue()).isEqualByComparingTo("5");
        put("/api/variants/" + sku + "/reorder-threshold", staff, m("reorderThreshold", -1), 400);
    }

    @Test
    void searchBySkuNameAndExactBarcode() throws Exception {
        Session owner = registerTenant();
        post("/api/products", owner, m("name", "Cà phê hòa tan", "variants",
                List.of(m("skuCode", "CF-HT-01", "retailPrice", 50000, "barcode", "4006381333931"))), 201);

        assertThat(get("/api/variants/search?q=cf-ht", owner).get("totalElements").asInt()).isEqualTo(1);
        assertThat(get("/api/variants/search?q=c%C3%A0%20ph%C3%AA", owner).get("totalElements").asInt()).isEqualTo(1);
        assertThat(get("/api/variants/search?q=4006381333931", owner).get("totalElements").asInt()).isEqualTo(1);
        assertThat(get("/api/variants/search?q=khong-co", owner).get("totalElements").asInt()).isZero();
    }

    @Test
    void rolePermissions() throws Exception {
        Session owner = registerTenant();
        Session cashier = createUserAndLogin(owner, "CASHIER");
        Session staff = createUserAndLogin(owner, "STAFF");
        createProduct(owner, "Hàng", "H-1", "10");
        UUID branch = createBranch(owner, "B1");
        UUID supplier = defaultSupplier(owner);

        // Cashier: đọc/tìm hàng được, tạo hàng bị cấm
        assertThat(get("/api/variants/search?q=H-1", cashier).get("totalElements").asInt()).isEqualTo(1);
        post("/api/products", cashier, m("name", "X", "variants", List.of(m("skuCode", "X-1", "retailPrice", 1))), 403);
        // Cashier không được xem sổ cái hay tạo phiếu nhập
        send(HttpMethod.GET, "/api/inventory/ledger", cashier, null, 403);
        post("/api/purchase-receipts", cashier, m("branchId", branch, "supplierId", supplier, "items",
                List.of(m("skuId", UUID.randomUUID(), "quantity", 1, "unitPrice", 1))), 403);
        // Staff tạo hàng được; không tạo được user, danh mục, thương hiệu
        post("/api/products", staff, m("name", "Y", "variants", List.of(m("skuCode", "Y-1", "retailPrice", 1))), 201);
        post("/api/users", staff, m("fullName", "n", "email", "n@x.vn", "password", "12345678", "role", "CASHIER"), 403);
        post("/api/categories", staff, m("name", "Cấm"), 403);
        post("/api/brands", staff, m("name", "Cấm"), 403);
        // Owner thì được
        post("/api/categories", owner, m("name", "Cho phép"), 201);
        post("/api/brands", owner, m("name", "Cho phép"), 201);
        // Chưa đăng nhập => 401
        send(HttpMethod.GET, "/api/products", null, null, 401);
    }

    @Test
    void categoriesAreHierarchicalAndProtected() throws Exception {
        Session owner = registerTenant();
        JsonNode root = post("/api/categories", owner, m("name", "Thời trang"), 201);
        String rootId = root.get("id").asText();
        JsonNode child = post("/api/categories", owner, m("name", "Áo", "parentId", rootId), 201);

        // trùng tên cùng cấp => 409; khác cấp => OK
        post("/api/categories", owner, m("name", "thời trang"), 409);
        post("/api/categories", owner, m("name", "Thời trang", "parentId", rootId), 201);
        // đặt cha là chính hậu duệ của mình => 400 (vòng lặp)
        put("/api/categories/" + rootId, owner, m("name", "Thời trang", "parentId", child.get("id").asText()), 400);
        // xoá danh mục còn con => 409
        send(HttpMethod.DELETE, "/api/categories/" + rootId, owner, null, 409);
        // danh mục đang có sản phẩm => 409
        post("/api/products", owner, m("name", "Áo thun", "categoryId", child.get("id").asText(),
                "variants", List.of(m("skuCode", "AO-1", "retailPrice", 1))), 201);
        send(HttpMethod.DELETE, "/api/categories/" + child.get("id").asText(), owner, null, 409);
    }

    @Test
    void productCanBeDeactivatedAndHiddenFromSearch() throws Exception {
        Session owner = registerTenant();
        JsonNode p = createProduct(owner, "Hàng cũ", "OLD-1", new BigDecimal("10").toPlainString());
        assertThat(get("/api/variants/search?q=OLD-1", owner).get("totalElements").asInt()).isEqualTo(1);
        JsonNode off = send(HttpMethod.PATCH, "/api/products/" + p.get("id").asText() + "/active?value=false", owner, null, 200);
        assertThat(off.get("active").asBoolean()).isFalse();
        assertThat(get("/api/variants/search?q=OLD-1", owner).get("totalElements").asInt()).isZero();
    }
}
