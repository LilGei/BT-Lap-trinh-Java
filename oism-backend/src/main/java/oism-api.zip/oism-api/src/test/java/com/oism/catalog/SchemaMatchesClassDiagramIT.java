package com.oism.catalog;

import com.oism.support.IntegrationTestBase;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Bằng chứng database khớp 4 sơ đồ lớp (Auth, Catalog, Inventory & Costing, Order).
 * Mỗi thuộc tính trong sơ đồ phải có cột tương ứng (quy ước snake_case); bảng/cột cũ đã bị loại.
 */
class SchemaMatchesClassDiagramIT extends IntegrationTestBase {
    @Autowired JdbcTemplate jdbc;

    private List<String> columns(String table) {
        return jdbc.queryForList("SELECT column_name FROM information_schema.columns "
                + "WHERE table_schema = 'public' AND table_name = ?", String.class, table);
    }

    private static final Map<String, List<String>> EXPECTED = Map.ofEntries(
            // ---- Authentication & Multi-Tenant ----
            Map.entry("tenants", List.of("id", "name", "domain", "status", "created_at")),
            Map.entry("roles", List.of("id", "name")),
            Map.entry("users", List.of("id", "tenant_id", "role_id", "email", "phone", "password_hash", "status", "created_at")),
            Map.entry("user_branches", List.of("user_id", "branch_id")),
            Map.entry("branches", List.of("id", "tenant_id", "name", "address", "type", "is_active")),
            Map.entry("refresh_tokens", List.of("id", "tenant_id", "user_id", "token_hash", "expires_at", "is_revoked")),
            // ---- Product Catalog ----
            Map.entry("categories", List.of("id", "tenant_id", "parent_id", "name")),
            Map.entry("brands", List.of("id", "tenant_id", "name")),
            Map.entry("products", List.of("id", "tenant_id", "category_id", "brand_id", "name", "description", "has_variants", "is_active")),
            Map.entry("product_variants", List.of("id", "tenant_id", "product_id", "sku_code", "color", "size",
                    "current_average_cost", "retail_price", "wholesale_price", "reorder_threshold", "is_active")),
            Map.entry("barcodes", List.of("id", "tenant_id", "sku_id", "code", "type")),
            // ---- Inventory & Costing ----
            Map.entry("suppliers", List.of("id", "tenant_id", "name", "phone")),
            Map.entry("purchase_receipts", List.of("id", "tenant_id", "branch_id", "supplier_id", "created_by",
                    "receipt_date", "total_amount", "status")),
            Map.entry("purchase_receipt_items", List.of("id", "tenant_id", "receipt_id", "sku_id", "quantity", "unit_price")),
            Map.entry("stock_balances", List.of("id", "tenant_id", "branch_id", "sku_id", "on_hand", "reserved", "version")),
            Map.entry("inventory_transactions", List.of("id", "tenant_id", "branch_id", "sku_id", "type", "reference_type",
                    "reference_id", "quantity", "balance_after", "unit_cost", "created_at")),
            Map.entry("stock_transfers", List.of("id", "tenant_id", "from_branch_id", "to_branch_id", "created_by",
                    "status", "created_at", "shipped_at", "received_at")),
            Map.entry("stock_transfer_items", List.of("id", "transfer_id", "sku_id", "quantity")),
            Map.entry("stocktakes", List.of("id", "tenant_id", "branch_id", "created_by", "status", "created_at", "completed_at")),
            Map.entry("stocktake_items", List.of("id", "stocktake_id", "sku_id", "system_qty", "actual_qty", "difference_qty")),
            // ---- Order Management ----
            Map.entry("orders", List.of("id", "tenant_id", "branch_id", "created_by", "order_code", "channel",
                    "external_order_id", "status", "total_amount", "created_at", "confirmed_at")),
            Map.entry("order_items", List.of("id", "tenant_id", "order_id", "sku_id", "quantity", "unit_price", "cost_price", "subtotal")),
            Map.entry("payments", List.of("id", "tenant_id", "order_id", "method", "amount", "status", "paid_at")),
            Map.entry("webhook_events", List.of("id", "tenant_id", "channel", "external_order_id", "payload", "status",
                    "received_at", "processed_at", "error_message")),
            Map.entry("notifications", List.of("id", "tenant_id", "user_id", "type", "title", "message", "reference_id",
                    "is_read", "created_at")));

    @Test
    void everyDiagramAttributeHasAColumn() {
        for (var e : EXPECTED.entrySet()) {
            assertThat(columns(e.getKey())).as("bảng %s", e.getKey()).containsAll(e.getValue());
        }
    }

    @Test
    void oldStructuresReplacedByDiagramStructures() {
        assertThat(columns("users")).doesNotContain("role", "branch_id", "active");
        assertThat(columns("tenants")).doesNotContain("code", "active");
        assertThat(columns("branches")).doesNotContain("is_warehouse");
        assertThat(columns("product_variants")).doesNotContain("barcode", "attributes", "sku", "avg_cost");
        assertThat(columns("inventory_transactions")).doesNotContain("reason", "note");
        assertThat(columns("orders")).doesNotContain("payment_method", "subtotal", "discount");
        assertThat(columns("stock_balances")).doesNotContain("reorder_point");
        assertThat(columns("stock_levels")).as("bảng stock_levels đã đổi thành stock_balances").isEmpty();
    }

    @Test
    void quantitiesAreDecimal() {
        for (String[] tc : new String[][]{
                {"stock_balances", "on_hand"}, {"stock_balances", "reserved"},
                {"inventory_transactions", "quantity"}, {"inventory_transactions", "balance_after"},
                {"purchase_receipt_items", "quantity"}, {"stock_transfer_items", "quantity"},
                {"stocktake_items", "system_qty"}, {"stocktake_items", "actual_qty"}, {"stocktake_items", "difference_qty"},
                {"order_items", "quantity"}}) {
            String type = jdbc.queryForObject("SELECT data_type FROM information_schema.columns "
                    + "WHERE table_schema = 'public' AND table_name = ? AND column_name = ?", String.class, tc[0], tc[1]);
            assertThat(type).as("%s.%s", tc[0], tc[1]).isEqualTo("numeric");
        }
    }

    @Test
    void rolesAreSeededAndTenantOnlyTablesCarryTenantId() {
        List<String> names = jdbc.queryForList("SELECT name FROM roles", String.class);
        assertThat(names).containsExactlyInAnyOrder("OWNER", "STAFF", "CASHIER");
        // mọi bảng nghiệp vụ theo tenant đều phải có tenant_id (NFR-TENANT-01)
        for (String t : List.of("branches", "categories", "brands", "products", "product_variants", "barcodes", "suppliers",
                "purchase_receipts", "purchase_receipt_items", "stock_balances", "inventory_transactions", "stock_transfers",
                "stock_transfer_items", "stocktakes", "stocktake_items", "orders", "order_items", "payments",
                "webhook_events", "notifications", "cost_history", "refresh_tokens", "users")) {
            assertThat(columns(t)).as("bảng %s", t).contains("tenant_id");
        }
    }

    @Test
    void ledgerReferenceTypeIsRestrictedToDiagramValues() {
        List<String> check = jdbc.queryForList("SELECT pg_get_constraintdef(oid) FROM pg_constraint "
                + "WHERE conname = 'ck_ledger_reference_type'", String.class);
        assertThat(check).hasSize(1);
        for (String v : List.of("PURCHASE_RECEIPT", "TRANSFER_OUT", "TRANSFER_IN", "SALE", "RETURN", "STOCKTAKE_ADJUST"))
            assertThat(check.get(0)).contains(v);
    }
}
