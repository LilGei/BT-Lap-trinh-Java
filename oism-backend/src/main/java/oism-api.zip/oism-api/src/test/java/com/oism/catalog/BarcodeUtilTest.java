package com.oism.catalog;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class BarcodeUtilTest {

    @Test
    void knownValidEan13() {
        assertThat(BarcodeUtil.isValidEan13("4006381333931")).isTrue();
    }

    @Test
    void wrongCheckDigitIsInvalid() {
        assertThat(BarcodeUtil.isValidEan13("4006381333932")).isFalse();
    }

    @Test
    void checkDigitComputation() {
        assertThat(BarcodeUtil.ean13CheckDigit("400638133393")).isEqualTo(1);
    }

    @Test
    void generatedCodesAreValidInternalEan13() {
        for (long seq : new long[]{0, 1, 42, 999_999_999L}) {
            String code = BarcodeUtil.buildEan13(seq);
            assertThat(code).hasSize(13).startsWith("200");
            assertThat(BarcodeUtil.isValidEan13(code)).isTrue();
        }
    }

    @Test
    void generatedCodesAreUniquePerSequence() {
        assertThat(BarcodeUtil.buildEan13(1)).isNotEqualTo(BarcodeUtil.buildEan13(2));
    }

    @Test
    void sequenceOutOfRangeRejected() {
        assertThatThrownBy(() -> BarcodeUtil.buildEan13(1_000_000_000L)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> BarcodeUtil.buildEan13(-1)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void code128Rules() {
        assertThat(BarcodeUtil.isValidCode128("ABC-123")).isTrue();
        assertThat(BarcodeUtil.isValidCode128("A".repeat(48))).isTrue();
        assertThat(BarcodeUtil.isValidCode128("A".repeat(49))).isFalse();
        assertThat(BarcodeUtil.isValidCode128("")).isFalse();
        assertThat(BarcodeUtil.isValidCode128("Đồ-chơi")).isFalse();   // ngoài ASCII
    }

    @Test
    void thirteenDigitsMustBeValidEan13ButOtherStringsFallBackToCode128() {
        assertThat(BarcodeUtil.isValid("4006381333931")).isTrue();
        assertThat(BarcodeUtil.isValid("4006381333932")).isFalse();   // 13 số nhưng sai check digit
        assertThat(BarcodeUtil.isValid("12345")).isTrue();            // Code128
        assertThat(BarcodeUtil.isValid(null)).isFalse();
    }

    @Test
    void typeOfClassifiesValidCodes() {
        assertThat(BarcodeUtil.typeOf("4006381333931")).isEqualTo(BarcodeType.EAN13);
        assertThat(BarcodeUtil.typeOf("ABC-123")).isEqualTo(BarcodeType.CODE128);
        assertThat(BarcodeUtil.typeOf("12345")).isEqualTo(BarcodeType.CODE128);
    }
}
