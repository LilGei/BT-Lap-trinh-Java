package com.oism.catalog;

/** FR-PROD-03: sinh & kiểm tra barcode EAN-13 / Code128. Lớp thuần, dễ unit test. */
public final class BarcodeUtil {
    /** Prefix 200-299 là dải GS1 dành cho mã dùng nội bộ cửa hàng (không đụng mã thương mại). */
    private static final String INTERNAL_PREFIX = "200";
    private BarcodeUtil() {}

    public static int ean13CheckDigit(String body12) {
        if (body12 == null || !body12.matches("\\d{12}")) throw new IllegalArgumentException("body must be 12 digits");
        int sum = 0;
        for (int i = 0; i < 12; i++) {
            int d = body12.charAt(i) - '0';
            sum += (i % 2 == 0) ? d : d * 3;
        }
        return (10 - (sum % 10)) % 10;
    }

    public static boolean isValidEan13(String code) {
        if (code == null || !code.matches("\\d{13}")) return false;
        return ean13CheckDigit(code.substring(0, 12)) == code.charAt(12) - '0';
    }

    /** seq < 1_000_000_000 -> "200" + 9 chữ số + check digit. */
    public static String buildEan13(long seq) {
        if (seq < 0 || seq >= 1_000_000_000L) throw new IllegalArgumentException("seq out of range");
        String body = INTERNAL_PREFIX + String.format("%09d", seq);
        return body + ean13CheckDigit(body);
    }

    /** Code128 (subset B): ký tự ASCII in được 32..126, độ dài 1..48. */
    public static boolean isValidCode128(String s) {
        if (s == null || s.isEmpty() || s.length() > 48) return false;
        for (char c : s.toCharArray()) if (c < 32 || c > 126) return false;
        return true;
    }

    /** 13 chữ số => bắt buộc là EAN-13 đúng check digit; còn lại xét như Code128. */
    public static boolean isValid(String code) {
        if (code == null) return false;
        if (code.matches("\\d{13}")) return isValidEan13(code);
        return isValidCode128(code);
    }

    /** Phân loại một mã ĐÃ hợp lệ: 13 chữ số => EAN13, còn lại => CODE128. */
    public static BarcodeType typeOf(String code) {
        return code.matches("\\d{13}") ? BarcodeType.EAN13 : BarcodeType.CODE128;
    }
}
