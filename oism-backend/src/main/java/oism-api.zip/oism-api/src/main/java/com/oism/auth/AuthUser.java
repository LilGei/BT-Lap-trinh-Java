package com.oism.auth;

import java.util.UUID;

public record AuthUser(UUID userId, UUID tenantId, RoleName role) {}
