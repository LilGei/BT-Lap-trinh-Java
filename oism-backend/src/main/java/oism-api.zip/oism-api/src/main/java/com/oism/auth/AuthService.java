package com.oism.auth;

import com.oism.auth.AuthDtos.*;
import com.oism.common.BusinessException;
import com.oism.tenant.Tenant;
import com.oism.tenant.TenantRepository;
import com.oism.tenant.TenantStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.HexFormat;

@Service
@RequiredArgsConstructor
public class AuthService {
    private static final SecureRandom RANDOM = new SecureRandom();

    private final TenantRepository tenants;
    private final UserRepository users;
    private final RoleRepository roles;
    private final RefreshTokenRepository refreshTokens;
    private final PasswordEncoder encoder;
    private final JwtService jwt;

    @Value("${app.jwt.refresh-ttl-days:7}")
    private long refreshTtlDays;

    /** FR-AUTH-01: tạo Tenant mới + tài khoản Owner. */
    @Transactional
    public AuthResponse registerTenant(RegisterTenantRequest r) {
        boolean hasEmail = r.email() != null && !r.email().isBlank();
        boolean hasPhone = r.phone() != null && !r.phone().isBlank();
        if (!hasEmail && !hasPhone)
            throw new BusinessException(HttpStatus.BAD_REQUEST, "Email or phone is required");
        if (tenants.existsByDomainIgnoreCase(r.domain()))
            throw new BusinessException(HttpStatus.CONFLICT, "Tenant domain already exists");
        if (hasEmail && users.existsByEmailIgnoreCase(r.email()))
            throw new BusinessException(HttpStatus.CONFLICT, "Email already used");
        if (hasPhone && users.existsByPhone(r.phone()))
            throw new BusinessException(HttpStatus.CONFLICT, "Phone already used");

        Tenant t = new Tenant();
        t.setDomain(r.domain());
        t.setName(r.storeName());
        t = tenants.save(t);

        User u = new User();
        u.setTenantId(t.getId());
        u.setRole(roles.findByName(RoleName.OWNER)
                .orElseThrow(() -> new IllegalStateException("Roles are not seeded (run Flyway V3)")));
        u.setEmail(hasEmail ? r.email() : null);
        u.setPhone(hasPhone ? r.phone() : null);
        u.setFullName(r.ownerName());
        u.setPasswordHash(encoder.encode(r.password()));
        u = users.save(u);
        return issue(u);
    }

    /** FR-AUTH-02 */
    @Transactional
    public AuthResponse login(LoginRequest r) {
        User u = users.findByIdentifier(r.identifier())
                .filter(x -> encoder.matches(r.password(), x.getPasswordHash()))
                .orElseThrow(() -> new BusinessException(HttpStatus.UNAUTHORIZED, "Invalid credentials"));
        requireCanLogin(u);
        return issue(u);
    }

    /** Đổi refresh token lấy cặp token mới (xoay vòng: token cũ bị thu hồi ngay). */
    @Transactional
    public AuthResponse refresh(String rawToken) {
        RefreshToken t = refreshTokens.findByTokenHash(hash(rawToken))
                .filter(x -> !x.isRevoked() && x.getExpiresAt().isAfter(Instant.now()))
                .orElseThrow(() -> new BusinessException(HttpStatus.UNAUTHORIZED, "Invalid or expired refresh token"));
        User u = users.findById(t.getUserId())
                .orElseThrow(() -> new BusinessException(HttpStatus.UNAUTHORIZED, "Invalid or expired refresh token"));
        requireCanLogin(u);
        t.setRevoked(true);
        return issue(u);
    }

    /** Đăng xuất: thu hồi refresh token. Idempotent (token lạ vẫn trả thành công). */
    @Transactional
    public void logout(String rawToken) {
        refreshTokens.findByTokenHash(hash(rawToken)).ifPresent(t -> t.setRevoked(true));
    }

    private void requireCanLogin(User u) {
        if (u.getStatus() != UserStatus.ACTIVE)
            throw new BusinessException(HttpStatus.FORBIDDEN, "Account is " + u.getStatus());
        Tenant t = tenants.findById(u.getTenantId())
                .orElseThrow(() -> new BusinessException(HttpStatus.FORBIDDEN, "Tenant not found"));
        if (t.getStatus() != TenantStatus.ACTIVE)
            throw new BusinessException(HttpStatus.FORBIDDEN, "Tenant is " + t.getStatus());
    }

    private AuthResponse issue(User u) {
        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        String raw = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);

        RefreshToken rt = new RefreshToken();
        rt.setTenantId(u.getTenantId());
        rt.setUserId(u.getId());
        rt.setTokenHash(hash(raw));
        rt.setExpiresAt(Instant.now().plus(Duration.ofDays(refreshTtlDays)));
        refreshTokens.save(rt);

        return new AuthResponse(jwt.generate(u), raw, "Bearer", jwt.ttlSeconds(),
                u.getTenantId(), u.getId(), u.getRole().getName());
    }

    private static String hash(String raw) {
        try {
            return HexFormat.of().formatHex(
                    MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
