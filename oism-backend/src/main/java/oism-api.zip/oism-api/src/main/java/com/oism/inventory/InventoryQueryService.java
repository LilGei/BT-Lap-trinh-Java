package com.oism.inventory;

import com.oism.catalog.ProductVariant;
import com.oism.catalog.ProductVariantRepository;
import com.oism.common.PageDto;
import com.oism.inventory.InventoryDtos.*;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class InventoryQueryService {
    private final StockBalanceRepository stocks;
    private final InventoryTransactionRepository ledger;
    private final ProductVariantRepository variants;

    @Transactional(readOnly = true)
    public PageDto<StockDto> stock(UUID branchId, UUID skuId, boolean lowStockOnly, int page, int size) {
        Specification<StockBalance> spec = (r, q, cb) -> cb.conjunction();
        if (branchId != null) spec = spec.and((r, q, cb) -> cb.equal(r.get("branchId"), branchId));
        if (skuId != null) spec = spec.and((r, q, cb) -> cb.equal(r.get("skuId"), skuId));
        if (lowStockOnly) {
            // FR-REP-03: available <= ProductVariant.reorderThreshold
            spec = spec.and((r, q, cb) -> {
                Subquery<Integer> sq = q.subquery(Integer.class);
                Root<ProductVariant> v = sq.from(ProductVariant.class);
                sq.select(cb.literal(1)).where(
                        cb.equal(v.get("id"), r.get("skuId")),
                        cb.greaterThanOrEqualTo(v.<BigDecimal>get("reorderThreshold"),
                                cb.diff(r.<BigDecimal>get("onHand"), r.<BigDecimal>get("reserved"))));
                return cb.exists(sq);
            });
        }
        Page<StockBalance> pg = stocks.findAll(spec, PageDto.pageable(page, size, Sort.by("skuId", "branchId")));
        Map<UUID, ProductVariant> byId = variants.findAllById(pg.getContent().stream().map(StockBalance::getSkuId).toList())
                .stream().collect(Collectors.toMap(ProductVariant::getId, v -> v));
        return PageDto.of(pg, pg.getContent().stream().map(s -> toDto(s, byId.get(s.getSkuId()))).toList());
    }

    @Transactional(readOnly = true)
    public PageDto<LedgerDto> ledger(UUID branchId, UUID skuId, int page, int size) {
        Specification<InventoryTransaction> spec = (r, q, cb) -> cb.conjunction();
        if (branchId != null) spec = spec.and((r, q, cb) -> cb.equal(r.get("branchId"), branchId));
        if (skuId != null) spec = spec.and((r, q, cb) -> cb.equal(r.get("skuId"), skuId));
        Page<InventoryTransaction> pg = ledger.findAll(spec, PageDto.pageable(page, size, Sort.by(Sort.Direction.DESC, "id")));
        return PageDto.of(pg, pg.getContent().stream().map(InventoryQueryService::toDto).toList());
    }

    static StockDto toDto(StockBalance s, ProductVariant v) {
        BigDecimal threshold = v == null ? BigDecimal.ZERO : v.getReorderThreshold();
        return new StockDto(s.getBranchId(), s.getSkuId(), v == null ? null : v.getSkuCode(), s.getOnHand(),
                s.getReserved(), s.available(), threshold, s.available().compareTo(threshold) <= 0);
    }

    static LedgerDto toDto(InventoryTransaction t) {
        return new LedgerDto(t.getId(), t.getBranchId(), t.getSkuId(), t.getType().name(), t.getReferenceType().name(),
                t.getReferenceId(), t.getQuantity(), t.getBalanceAfter(), t.getUnitCost(), t.getCreatedAt());
    }
}
