package com.oism.cost;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** FR-COST-01: giá vốn bình quân gia quyền. Lớp thuần (không phụ thuộc Spring) để test nhanh. */
public final class CostCalculator {
    public static final int SCALE = 4;
    private CostCalculator() {}

    /**
     * newCost = (oldStock * oldCost + importQty * importPrice) / (oldStock + importQty)
     * Tồn cũ <= 0 thì giá vốn mới = giá nhập (không để tồn âm kéo lệch giá).
     */
    public static BigDecimal weightedAverage(BigDecimal oldStock, BigDecimal oldCost,
                                             BigDecimal importQty, BigDecimal importPrice) {
        if (importQty == null || importQty.signum() <= 0) throw new IllegalArgumentException("importQty must be > 0");
        if (importPrice == null || importPrice.signum() < 0) throw new IllegalArgumentException("importPrice must be >= 0");
        if (oldStock == null || oldStock.signum() <= 0) return importPrice.setScale(SCALE, RoundingMode.HALF_UP);
        BigDecimal cost = oldCost == null ? BigDecimal.ZERO : oldCost;
        BigDecimal total = cost.multiply(oldStock).add(importPrice.multiply(importQty));
        return total.divide(oldStock.add(importQty), SCALE, RoundingMode.HALF_UP);
    }

    /** Tiện cho số lượng nguyên. */
    public static BigDecimal weightedAverage(long oldStock, BigDecimal oldCost, long importQty, BigDecimal importPrice) {
        return weightedAverage(BigDecimal.valueOf(oldStock), oldCost, BigDecimal.valueOf(importQty), importPrice);
    }
}
