package com.oism.common;

import org.springframework.http.HttpStatus;

public class BusinessException extends RuntimeException {
    private final HttpStatus status;
    public BusinessException(HttpStatus status, String message) { super(message); this.status = status; }
    public HttpStatus getStatus() { return status; }

    public static BusinessException notFound(String what) { return new BusinessException(HttpStatus.NOT_FOUND, what + " not found"); }
    public static BusinessException conflict(String msg)  { return new BusinessException(HttpStatus.CONFLICT, msg); }
    public static BusinessException badRequest(String msg){ return new BusinessException(HttpStatus.BAD_REQUEST, msg); }
}
