package com.oism.common;

import org.springframework.http.HttpStatus;

import java.math.BigDecimal;

public class InsufficientStockException extends BusinessException {
    public InsufficientStockException(BigDecimal available, BigDecimal requested) {
        super(HttpStatus.CONFLICT, "Insufficient stock: available=" + available.stripTrailingZeros().toPlainString()
                + ", requested=" + requested.stripTrailingZeros().toPlainString());
    }
}
