package com.oism.common;

import com.oism.tenant.TenantContext;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/** Sinh số tăng dần theo (tenant, loại chứng từ) bằng upsert nguyên tử của PostgreSQL. */
@Service
public class DocumentNumberService {
    @PersistenceContext
    private EntityManager em;

    @Transactional(propagation = Propagation.MANDATORY)
    public long nextValue(String docType) {
        Number n = (Number) em.createNativeQuery(
                "INSERT INTO doc_counters (tenant_id, doc_type, last_value) VALUES (:t, :d, 1) " +
                "ON CONFLICT (tenant_id, doc_type) DO UPDATE SET last_value = doc_counters.last_value + 1 " +
                "RETURNING last_value")
                .setParameter("t", TenantContext.require())
                .setParameter("d", docType)
                .getSingleResult();
        return n.longValue();
    }

    public String nextCode(String prefix, String docType) {
        return prefix + "-" + String.format("%06d", nextValue(docType));
    }
}
