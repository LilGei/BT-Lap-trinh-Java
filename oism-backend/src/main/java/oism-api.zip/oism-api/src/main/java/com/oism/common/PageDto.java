package com.oism.common;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.List;

public record PageDto<T>(List<T> content, int page, int size, long totalElements, int totalPages) {
    public static <T> PageDto<T> of(Page<?> p, List<T> content) {
        return new PageDto<>(content, p.getNumber(), p.getSize(), p.getTotalElements(), p.getTotalPages());
    }
    /** size bị chặn tối đa 100. */
    public static Pageable pageable(int page, int size, Sort sort) {
        return PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100), sort);
    }
}
