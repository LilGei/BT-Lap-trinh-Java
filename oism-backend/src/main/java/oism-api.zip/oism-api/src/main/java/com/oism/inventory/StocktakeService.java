package com.oism.inventory;

import com.oism.branch.BranchRepository;
import com.oism.catalog.ProductVariantRepository;
import com.oism.common.BusinessException;
import com.oism.common.DocumentNumberService;
import com.oism.common.EntityLookup;
import com.oism.common.PageDto;
import com.oism.inventory.InventoryDtos.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/** FR-INV-04: phiên kiểm kê -> nhập số đếm -> hoàn tất => sinh bút toán STOCKTAKE_ADJUST cho phần chênh lệch. */
@Service
@RequiredArgsConstructor
public class StocktakeService {
    private final StocktakeRepository stocktakes;
    private final StocktakeItemRepository items;
    private final StockBalanceRepository stocks;
    private final BranchRepository branches;
    private final ProductVariantRepository variants;
    private final InventoryService inventory;
    private final DocumentNumberService docNumbers;

    @Transactional
    public StocktakeDto create(StocktakeRequest r, UUID userId) {
        branches.requireActive(r.branchId());
        Stocktake s = new Stocktake();
        s.setBranchId(r.branchId());
        s.setNote(r.note());
        s.setCreatedBy(userId);
        s.setCode(docNumbers.nextCode("KK", "STOCKTAKE"));
        return toDto(stocktakes.save(s));
    }

    /** Ghi (hoặc ghi đè) số đếm thực tế; systemQty là số trên phần mềm tại thời điểm đếm. */
    @Transactional
    public StocktakeDto recordCounts(UUID id, CountsRequest r) {
        Stocktake st = EntityLookup.require(stocktakes, id, "Stocktake");
        requireInProgress(st);
        for (CountItemRequest c : r.items()) {
            EntityLookup.require(variants, c.skuId(), "SKU");
            BigDecimal system = stocks.findByBranchIdAndSkuId(st.getBranchId(), c.skuId())
                    .map(StockBalance::getOnHand).orElse(BigDecimal.ZERO);
            StocktakeItem item = items.findByStocktakeIdAndSkuId(id, c.skuId()).orElseGet(() -> {
                StocktakeItem n = new StocktakeItem();
                n.setStocktakeId(id);
                n.setSkuId(c.skuId());
                return n;
            });
            item.setSystemQty(system);
            item.setActualQty(c.actualQty());
            item.setDifferenceQty(c.actualQty().subtract(system));
            items.saveAndFlush(item);
        }
        return toDto(st);
    }

    /**
     * Hoàn tất: với từng dòng, so số đếm với tồn HIỆN TẠI (đã khoá dòng) rồi ghi ledger.
     * Cả phiên nằm trong 1 transaction: lỗi 1 dòng => không dòng nào được điều chỉnh.
     */
    @Transactional
    public StocktakeDto complete(UUID id, UUID userId) {
        Stocktake st = EntityLookup.require(stocktakes, id, "Stocktake");
        requireInProgress(st);
        List<StocktakeItem> list = items.findByStocktakeId(id).stream()
                .sorted(Comparator.comparing(StocktakeItem::getSkuId)).toList();
        if (list.isEmpty()) throw BusinessException.badRequest("No counted items to complete");
        for (StocktakeItem it : list) {
            BigDecimal diff = inventory.adjustTo(st.getBranchId(), it.getSkuId(), it.getActualQty(), st.getId(), userId);
            it.setSystemQty(it.getActualQty().subtract(diff));   // on_hand ngay trước khi điều chỉnh
            it.setDifferenceQty(diff);
        }
        st.setStatus(Stocktake.Status.COMPLETED);
        st.setCompletedAt(Instant.now());
        return toDto(st);
    }

    /** Bỏ phiên đang đếm dở (không ảnh hưởng tồn kho vì chưa ghi ledger). */
    @Transactional
    public void delete(UUID id) {
        Stocktake st = EntityLookup.require(stocktakes, id, "Stocktake");
        requireInProgress(st);
        items.deleteAll(items.findByStocktakeId(id));
        stocktakes.delete(st);
    }

    @Transactional(readOnly = true)
    public StocktakeDto get(UUID id) { return toDto(EntityLookup.require(stocktakes, id, "Stocktake")); }

    @Transactional(readOnly = true)
    public PageDto<StocktakeDto> list(int page, int size) {
        Page<Stocktake> pg = stocktakes.findAllByOrderByCreatedAtDesc(PageDto.pageable(page, size, Sort.unsorted()));
        return PageDto.of(pg, pg.getContent().stream().map(this::toDto).toList());
    }

    private static void requireInProgress(Stocktake st) {
        if (st.getStatus() != Stocktake.Status.IN_PROGRESS)
            throw BusinessException.conflict("Stocktake is " + st.getStatus());
    }

    private StocktakeDto toDto(Stocktake st) {
        List<StocktakeItemDto> dtos = items.findByStocktakeId(st.getId()).stream()
                .sorted(Comparator.comparing(StocktakeItem::getSkuId))
                .map(i -> new StocktakeItemDto(i.getSkuId(), i.getSystemQty(), i.getActualQty(), i.getDifferenceQty()))
                .toList();
        return new StocktakeDto(st.getId(), st.getCode(), st.getBranchId(), st.getStatus().name(), st.getNote(),
                st.getCompletedAt(), st.getCreatedAt(), dtos);
    }
}
