package com.oism.catalog;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

public final class CatalogDtos {
    private CatalogDtos() {}

    public record CategoryRequest(@NotBlank @Size(max = 200) String name, UUID parentId) {}
    public record CategoryDto(UUID id, UUID parentId, String name) {}
    public record BrandRequest(@NotBlank @Size(max = 200) String name) {}
    public record BrandDto(UUID id, String name) {}

    /** skuCode để trống => hệ thống tự sinh (SKU-000001). barcode = nhập tay; autoBarcode = tự sinh EAN-13. */
    public record VariantRequest(
            @Size(max = 80) String skuCode,
            @Size(max = 50) String color,
            @Size(max = 50) String size,
            String barcode,
            boolean autoBarcode,
            @NotNull @DecimalMin("0") BigDecimal retailPrice,
            @DecimalMin("0") BigDecimal wholesalePrice,
            @DecimalMin("0") BigDecimal reorderThreshold) {}

    /** categoryId để trống => vào danh mục mặc định "Chưa phân loại". */
    public record ProductRequest(
            @NotBlank @Size(max = 300) String name,
            String description,
            UUID categoryId,
            UUID brandId,
            @NotEmpty @Valid List<VariantRequest> variants) {}

    public record ProductUpdateRequest(
            @NotBlank @Size(max = 300) String name,
            String description,
            UUID categoryId,
            UUID brandId) {}

    public record PriceRequest(
            @NotNull @DecimalMin("0") BigDecimal retailPrice,
            @NotNull @DecimalMin("0") BigDecimal wholesalePrice) {}

    public record ThresholdRequest(@NotNull @DecimalMin("0") BigDecimal reorderThreshold) {}
    public record BarcodeRequest(@NotBlank String code) {}

    public record BarcodeDto(UUID id, String code, String type) {}

    public record VariantDto(UUID id, UUID productId, String skuCode, String color, String size,
                             BigDecimal currentAverageCost, BigDecimal retailPrice, BigDecimal wholesalePrice,
                             BigDecimal reorderThreshold, boolean active, List<BarcodeDto> barcodes) {}

    public record ProductDto(UUID id, String name, String description, UUID categoryId, UUID brandId,
                             boolean hasVariants, boolean active, List<VariantDto> variants) {}
}
