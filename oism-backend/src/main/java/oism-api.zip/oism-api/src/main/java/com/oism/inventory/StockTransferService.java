package com.oism.inventory;

import com.oism.branch.BranchRepository;
import com.oism.catalog.ProductVariantRepository;
import com.oism.common.BusinessException;
import com.oism.common.DocumentNumberService;
import com.oism.common.EntityLookup;
import com.oism.common.PageDto;
import com.oism.inventory.InventoryDtos.*;
import com.oism.inventory.InventoryTransaction.ReferenceType;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/** FR-INV-03: chuyển kho 2 bước. DRAFT -> ship (xuất khỏi kho gửi) -> IN_TRANSIT -> receive (nhập kho nhận) -> RECEIVED. */
@Service
@RequiredArgsConstructor
public class StockTransferService {
    private final StockTransferRepository transfers;
    private final BranchRepository branches;
    private final ProductVariantRepository variants;
    private final InventoryService inventory;
    private final DocumentNumberService docNumbers;

    @Transactional
    public TransferDto create(TransferRequest r, UUID userId) {
        if (r.fromBranchId().equals(r.toBranchId()))
            throw BusinessException.badRequest("Source and destination branches must be different");
        branches.requireActive(r.fromBranchId());
        branches.requireActive(r.toBranchId());

        StockTransfer t = new StockTransfer();
        t.setCode(docNumbers.nextCode("CK", "TRANSFER"));
        t.setFromBranchId(r.fromBranchId());
        t.setToBranchId(r.toBranchId());
        t.setNote(r.note());
        t.setCreatedBy(userId);
        for (TransferItemRequest i : r.items()) {
            EntityLookup.require(variants, i.skuId(), "SKU");
            StockTransferItem item = new StockTransferItem();
            item.setSkuId(i.skuId());
            item.setQuantity(i.quantity());
            t.getItems().add(item);
        }
        return toDto(transfers.save(t));
    }

    /** Bước 1: trừ tồn kho gửi (ledger TRANSFER_OUT). Thiếu hàng ở bất kỳ dòng nào => rollback tất cả, phiếu vẫn DRAFT. */
    @Transactional
    public TransferDto ship(UUID id, UUID userId) {
        StockTransfer t = EntityLookup.require(transfers, id, "Stock transfer");
        requireStatus(t, StockTransfer.Status.DRAFT, "shipped");
        for (StockTransferItem it : sorted(t)) {
            inventory.issue(t.getFromBranchId(), it.getSkuId(), it.getQuantity(),
                    ReferenceType.TRANSFER_OUT, t.getId(), userId);
        }
        t.setStatus(StockTransfer.Status.IN_TRANSIT);
        t.setShippedAt(Instant.now());
        return toDto(t);
    }

    /** Bước 2: kho nhận xác nhận (ledger TRANSFER_IN). */
    @Transactional
    public TransferDto receive(UUID id, UUID userId) {
        StockTransfer t = EntityLookup.require(transfers, id, "Stock transfer");
        requireStatus(t, StockTransfer.Status.IN_TRANSIT, "received");
        branches.requireActive(t.getToBranchId());
        for (StockTransferItem it : sorted(t)) {
            inventory.receive(t.getToBranchId(), it.getSkuId(), it.getQuantity(), null,
                    ReferenceType.TRANSFER_IN, t.getId(), userId);
        }
        t.setStatus(StockTransfer.Status.RECEIVED);
        t.setReceivedAt(Instant.now());
        return toDto(t);
    }

    @Transactional
    public TransferDto cancel(UUID id) {
        StockTransfer t = EntityLookup.require(transfers, id, "Stock transfer");
        requireStatus(t, StockTransfer.Status.DRAFT, "cancelled");
        t.setStatus(StockTransfer.Status.CANCELLED);
        return toDto(t);
    }

    @Transactional(readOnly = true)
    public TransferDto get(UUID id) { return toDto(EntityLookup.require(transfers, id, "Stock transfer")); }

    @Transactional(readOnly = true)
    public PageDto<TransferDto> list(int page, int size) {
        Page<StockTransfer> pg = transfers.findAllByOrderByCreatedAtDesc(PageDto.pageable(page, size, Sort.unsorted()));
        return PageDto.of(pg, pg.getContent().stream().map(StockTransferService::toDto).toList());
    }

    private static void requireStatus(StockTransfer t, StockTransfer.Status expected, String action) {
        if (t.getStatus() != expected)
            throw BusinessException.conflict("Transfer is " + t.getStatus() + ", cannot be " + action);
    }

    private static List<StockTransferItem> sorted(StockTransfer t) {
        List<StockTransferItem> l = new ArrayList<>(t.getItems());
        l.sort(Comparator.comparing(StockTransferItem::getSkuId));   // thứ tự khoá cố định, tránh deadlock
        return l;
    }

    static TransferDto toDto(StockTransfer t) {
        return new TransferDto(t.getId(), t.getCode(), t.getFromBranchId(), t.getToBranchId(), t.getStatus().name(),
                t.getNote(), t.getShippedAt(), t.getReceivedAt(), t.getCreatedAt(),
                t.getItems().stream().map(i -> new TransferItemRequest(i.getSkuId(), i.getQuantity())).toList());
    }
}
