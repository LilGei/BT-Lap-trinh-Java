package com.oism.inventory;

import com.oism.common.BusinessException;
import com.oism.common.InsufficientStockException;
import com.oism.inventory.InventoryTransaction.ReferenceType;
import com.oism.inventory.InventoryTransaction.Type;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/**
 * Cổng DUY NHẤT được phép thay đổi tồn kho. Mọi thay đổi on_hand đều đi kèm 1 dòng ledger
 * trong CÙNG transaction (MANDATORY => phải được gọi từ transaction của use case: ACID, NFR-SEC-02).
 */
@Service
@RequiredArgsConstructor
public class InventoryService {
    private final StockBalanceRepository stocks;
    private final InventoryTransactionRepository ledger;

    /** FR-RSE-02: giữ hàng cho đơn online. Từ chối nếu available < qty. */
    @Transactional(propagation = Propagation.MANDATORY)
    public void reserve(UUID branchId, UUID skuId, BigDecimal qty) {
        StockBalance s = lock(branchId, skuId, qty);
        if (s.available().compareTo(qty) < 0) throw new InsufficientStockException(s.available(), qty);
        s.setReserved(s.getReserved().add(qty));
        s.setUpdatedAt(Instant.now());
    }

    /** FR-RSE-03 (Cancelled): trả hàng giữ về available. */
    @Transactional(propagation = Propagation.MANDATORY)
    public void release(UUID branchId, UUID skuId, BigDecimal qty) {
        StockBalance s = lock(branchId, skuId, qty);
        s.setReserved(s.getReserved().subtract(qty).max(BigDecimal.ZERO));
        s.setUpdatedAt(Instant.now());
    }

    /** FR-RSE-03 (Confirmed): trừ on_hand, giảm reserved, ghi ledger OUT. */
    @Transactional(propagation = Propagation.MANDATORY)
    public void deductReserved(UUID branchId, UUID skuId, BigDecimal qty, ReferenceType ref, UUID refId, UUID userId) {
        StockBalance s = lock(branchId, skuId, qty);
        if (s.getReserved().compareTo(qty) < 0) throw new InsufficientStockException(s.getReserved(), qty);
        s.setOnHand(s.getOnHand().subtract(qty));
        s.setReserved(s.getReserved().subtract(qty));
        s.setUpdatedAt(Instant.now());
        append(s, Type.OUT, ref, refId, qty, null, userId);
    }

    /** Xuất trực tiếp (xuất chuyển kho...) từ hàng đang available, không đi qua reserve. */
    @Transactional(propagation = Propagation.MANDATORY)
    public void issue(UUID branchId, UUID skuId, BigDecimal qty, ReferenceType ref, UUID refId, UUID userId) {
        StockBalance s = lock(branchId, skuId, qty);
        if (s.available().compareTo(qty) < 0) throw new InsufficientStockException(s.available(), qty);
        s.setOnHand(s.getOnHand().subtract(qty));
        s.setUpdatedAt(Instant.now());
        append(s, Type.OUT, ref, refId, qty, null, userId);
    }

    /** FR-INV-02: nhập kho -> tăng on_hand + ghi ledger IN. Giá vốn bình quân do PurchaseService tính. */
    @Transactional(propagation = Propagation.MANDATORY)
    public void receive(UUID branchId, UUID skuId, BigDecimal qty, BigDecimal unitCost,
                        ReferenceType ref, UUID refId, UUID userId) {
        StockBalance s = getOrCreate(branchId, skuId);
        s.setOnHand(s.getOnHand().add(qty));
        s.setUpdatedAt(Instant.now());
        append(s, Type.IN, ref, refId, qty, unitCost, userId);
    }

    /**
     * FR-INV-04: đưa on_hand về đúng số đếm thực tế bằng 1 bút toán STOCKTAKE_ADJUST
     * (IN nếu thừa, OUT nếu thiếu).
     * @return chênh lệch = actual - on_hand trước đó (0 = khớp, không ghi ledger)
     */
    @Transactional(propagation = Propagation.MANDATORY)
    public BigDecimal adjustTo(UUID branchId, UUID skuId, BigDecimal actual, UUID refId, UUID userId) {
        StockBalance s = getOrCreate(branchId, skuId);
        BigDecimal diff = actual.subtract(s.getOnHand());
        if (diff.signum() == 0) return BigDecimal.ZERO;
        if (diff.signum() > 0) {
            s.setOnHand(actual);
            s.setUpdatedAt(Instant.now());
            append(s, Type.IN, ReferenceType.STOCKTAKE_ADJUST, refId, diff, null, userId);
        } else {
            if (actual.compareTo(s.getReserved()) < 0)
                throw BusinessException.conflict("Counted quantity (" + actual.stripTrailingZeros().toPlainString()
                        + ") is below reserved quantity (" + s.getReserved().stripTrailingZeros().toPlainString()
                        + "); resolve pending orders first");
            s.setOnHand(actual);
            s.setUpdatedAt(Instant.now());
            append(s, Type.OUT, ReferenceType.STOCKTAKE_ADJUST, refId, diff.negate(), null, userId);
        }
        return diff;
    }

    private StockBalance getOrCreate(UUID branchId, UUID skuId) {
        return stocks.findForUpdate(branchId, skuId).orElseGet(() -> {
            StockBalance n = new StockBalance();
            n.setBranchId(branchId);
            n.setSkuId(skuId);
            return stocks.saveAndFlush(n);
        });
    }

    private StockBalance lock(UUID branchId, UUID skuId, BigDecimal requested) {
        return stocks.findForUpdate(branchId, skuId)
                .orElseThrow(() -> new InsufficientStockException(BigDecimal.ZERO, requested));
    }

    private void append(StockBalance s, Type type, ReferenceType ref, UUID refId, BigDecimal qty,
                        BigDecimal cost, UUID userId) {
        InventoryTransaction t = new InventoryTransaction();
        t.setBranchId(s.getBranchId());
        t.setSkuId(s.getSkuId());
        t.setType(type);
        t.setReferenceType(ref);
        t.setReferenceId(refId);
        t.setQuantity(qty);
        t.setBalanceAfter(s.getOnHand());
        t.setUnitCost(cost);
        t.setCreatedBy(userId);
        ledger.save(t);
    }
}
