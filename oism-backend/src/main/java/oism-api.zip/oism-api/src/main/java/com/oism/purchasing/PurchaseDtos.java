package com.oism.purchasing;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public final class PurchaseDtos {
    private PurchaseDtos() {}

    public record SupplierRequest(@NotBlank @Size(max = 200) String name, String phone, String address) {}
    public record SupplierDto(UUID id, String name, String phone, String address, boolean active) {}

    public record ReceiptItemRequest(@NotNull UUID skuId,
                                     @NotNull @DecimalMin("0.001") @Digits(integer = 15, fraction = 3) BigDecimal quantity,
                                     @NotNull @DecimalMin("0") BigDecimal unitPrice) {}
    /** supplierId bắt buộc theo sơ đồ. receiptDate để trống => thời điểm tạo phiếu. */
    public record ReceiptRequest(@NotNull UUID branchId, @NotNull UUID supplierId, Instant receiptDate, String note,
                                 @NotEmpty @Valid List<ReceiptItemRequest> items) {}

    public record ReceiptItemDto(UUID skuId, BigDecimal quantity, BigDecimal unitPrice) {}
    public record ReceiptDto(UUID id, String code, UUID branchId, UUID supplierId, String status, String note,
                             Instant receiptDate, BigDecimal totalAmount, Instant confirmedAt, Instant createdAt,
                             List<ReceiptItemDto> items) {}
}
