package com.oism.inventory;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public final class InventoryDtos {
    private InventoryDtos() {}

    // ----- stock / ledger -----
    public record StockDto(UUID branchId, UUID skuId, String skuCode, BigDecimal onHand, BigDecimal reserved,
                           BigDecimal available, BigDecimal reorderThreshold, boolean lowStock) {}
    public record LedgerDto(Long id, UUID branchId, UUID skuId, String type, String referenceType, UUID referenceId,
                            BigDecimal quantity, BigDecimal balanceAfter, BigDecimal unitCost, Instant createdAt) {}

    // ----- stock transfer -----
    public record TransferItemRequest(@NotNull UUID skuId,
                                      @NotNull @DecimalMin("0.001") @Digits(integer = 15, fraction = 3) BigDecimal quantity) {}
    public record TransferRequest(@NotNull UUID fromBranchId, @NotNull UUID toBranchId, String note,
                                  @NotEmpty @Valid List<TransferItemRequest> items) {}
    public record TransferDto(UUID id, String code, UUID fromBranchId, UUID toBranchId, String status, String note,
                              Instant shippedAt, Instant receivedAt, Instant createdAt,
                              List<TransferItemRequest> items) {}

    // ----- stocktake -----
    public record StocktakeRequest(@NotNull UUID branchId, String note) {}
    public record CountItemRequest(@NotNull UUID skuId,
                                   @NotNull @DecimalMin("0") @Digits(integer = 15, fraction = 3) BigDecimal actualQty) {}
    public record CountsRequest(@NotEmpty @Valid List<CountItemRequest> items) {}
    public record StocktakeItemDto(UUID skuId, BigDecimal systemQty, BigDecimal actualQty, BigDecimal differenceQty) {}
    public record StocktakeDto(UUID id, String code, UUID branchId, String status, String note,
                               Instant completedAt, Instant createdAt, List<StocktakeItemDto> items) {}
}
