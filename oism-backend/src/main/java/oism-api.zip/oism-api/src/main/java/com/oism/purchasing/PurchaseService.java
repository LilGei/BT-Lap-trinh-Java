package com.oism.purchasing;

import com.oism.branch.BranchRepository;
import com.oism.catalog.ProductVariant;
import com.oism.catalog.ProductVariantRepository;
import com.oism.common.BusinessException;
import com.oism.common.DocumentNumberService;
import com.oism.common.EntityLookup;
import com.oism.common.PageDto;
import com.oism.cost.CostCalculator;
import com.oism.cost.CostHistory;
import com.oism.cost.CostHistoryRepository;
import com.oism.inventory.InventoryService;
import com.oism.inventory.InventoryTransaction.ReferenceType;
import com.oism.inventory.StockBalanceRepository;
import com.oism.purchasing.PurchaseDtos.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class PurchaseService {
    private final PurchaseReceiptRepository receipts;
    private final SupplierRepository suppliers;
    private final BranchRepository branches;
    private final ProductVariantRepository variants;
    private final StockBalanceRepository stocks;
    private final CostHistoryRepository costHistory;
    private final InventoryService inventory;
    private final DocumentNumberService docNumbers;

    @Transactional
    public ReceiptDto create(ReceiptRequest r, UUID userId) {
        branches.requireActive(r.branchId());
        EntityLookup.require(suppliers, r.supplierId(), "Supplier");

        PurchaseReceipt pr = new PurchaseReceipt();
        pr.setBranchId(r.branchId());
        pr.setSupplierId(r.supplierId());
        pr.setNote(r.note());
        pr.setCreatedBy(userId);
        if (r.receiptDate() != null) pr.setReceiptDate(r.receiptDate());
        pr.setCode(docNumbers.nextCode("PN", "RECEIPT"));

        BigDecimal total = BigDecimal.ZERO;
        for (ReceiptItemRequest i : r.items()) {
            EntityLookup.require(variants, i.skuId(), "SKU");
            PurchaseReceiptItem item = new PurchaseReceiptItem();
            item.setSkuId(i.skuId());
            item.setQuantity(i.quantity());
            item.setUnitPrice(i.unitPrice());
            pr.getItems().add(item);
            total = total.add(i.unitPrice().multiply(i.quantity()));
        }
        pr.setTotalAmount(total.setScale(2, RoundingMode.HALF_UP));
        return toDto(receipts.save(pr));
    }

    /**
     * FR-INV-02 + FR-COST-01: xác nhận phiếu nhập trong MỘT transaction:
     * khoá SKU -> tính giá vốn bình quân -> tăng on_hand -> ghi ledger IN. Lỗi bất kỳ => rollback toàn bộ.
     */
    @Transactional
    public ReceiptDto confirm(UUID id, UUID userId) {
        PurchaseReceipt pr = EntityLookup.require(receipts, id, "Purchase receipt");
        if (pr.getStatus() != PurchaseReceipt.Status.DRAFT)
            throw BusinessException.conflict("Receipt is " + pr.getStatus() + ", only DRAFT can be confirmed");
        branches.requireActive(pr.getBranchId());

        // khoá SKU theo thứ tự cố định để 2 phiếu nhập chéo nhau không deadlock
        List<PurchaseReceiptItem> ordered = new ArrayList<>(pr.getItems());
        ordered.sort(Comparator.comparing(PurchaseReceiptItem::getSkuId));

        for (PurchaseReceiptItem it : ordered) {
            ProductVariant v = variants.findForUpdate(it.getSkuId())
                    .orElseThrow(() -> BusinessException.notFound("SKU"));
            BigDecimal oldStock = stocks.totalOnHand(v.getId());
            BigDecimal newCost = CostCalculator.weightedAverage(oldStock, v.getCurrentAverageCost(),
                    it.getQuantity(), it.getUnitPrice());

            CostHistory h = new CostHistory();
            h.setSkuId(v.getId());
            h.setReceiptId(pr.getId());
            h.setOldStock(oldStock);
            h.setOldCost(v.getCurrentAverageCost());
            h.setImportQty(it.getQuantity());
            h.setImportPrice(it.getUnitPrice());
            h.setNewCost(newCost);
            costHistory.save(h);

            v.setCurrentAverageCost(newCost);
            inventory.receive(pr.getBranchId(), v.getId(), it.getQuantity(), it.getUnitPrice(),
                    ReferenceType.PURCHASE_RECEIPT, pr.getId(), userId);
        }
        pr.setStatus(PurchaseReceipt.Status.CONFIRMED);
        pr.setConfirmedAt(Instant.now());
        return toDto(pr);
    }

    @Transactional
    public ReceiptDto cancel(UUID id) {
        PurchaseReceipt pr = EntityLookup.require(receipts, id, "Purchase receipt");
        if (pr.getStatus() != PurchaseReceipt.Status.DRAFT)
            throw BusinessException.conflict("Only DRAFT receipts can be cancelled (confirmed stock changes are permanent in the ledger)");
        pr.setStatus(PurchaseReceipt.Status.CANCELLED);
        return toDto(pr);
    }

    @Transactional(readOnly = true)
    public ReceiptDto get(UUID id) { return toDto(EntityLookup.require(receipts, id, "Purchase receipt")); }

    @Transactional(readOnly = true)
    public PageDto<ReceiptDto> list(int page, int size) {
        Page<PurchaseReceipt> pg = receipts.findAllByOrderByCreatedAtDesc(PageDto.pageable(page, size, Sort.unsorted()));
        return PageDto.of(pg, pg.getContent().stream().map(PurchaseService::toDto).toList());
    }

    static ReceiptDto toDto(PurchaseReceipt p) {
        return new ReceiptDto(p.getId(), p.getCode(), p.getBranchId(), p.getSupplierId(), p.getStatus().name(),
                p.getNote(), p.getReceiptDate(), p.getTotalAmount(), p.getConfirmedAt(), p.getCreatedAt(),
                p.getItems().stream().map(i -> new ReceiptItemDto(i.getSkuId(), i.getQuantity(), i.getUnitPrice())).toList());
    }
}
