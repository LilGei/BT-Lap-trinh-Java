package com.oism.catalog;

import com.oism.catalog.CatalogDtos.*;
import com.oism.common.BusinessException;
import com.oism.common.DocumentNumberService;
import com.oism.common.EntityLookup;
import com.oism.common.PageDto;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductService {
    static final String DEFAULT_CATEGORY = "Chưa phân loại";
    private static final String BARCODE_SEQ = "BARCODE";

    private final ProductRepository products;
    private final ProductVariantRepository variants;
    private final BarcodeRepository barcodes;
    private final CategoryRepository categories;
    private final BrandRepository brands;
    private final DocumentNumberService docNumbers;

    // ---------- FR-PROD-02 ----------
    @Transactional
    public ProductDto create(ProductRequest r) {
        UUID categoryId = resolveCategory(r.categoryId());
        if (r.brandId() != null) EntityLookup.require(brands, r.brandId(), "Brand");
        Set<String> seen = new HashSet<>();
        for (VariantRequest v : r.variants()) {
            if (notBlank(v.skuCode()) && !seen.add(v.skuCode().trim().toLowerCase()))
                throw BusinessException.conflict("Duplicate SKU in request: " + v.skuCode().trim());
        }
        boolean hasVariants = r.variants().size() > 1
                || r.variants().stream().anyMatch(v -> notBlank(v.color()) || notBlank(v.size()));

        Product p = new Product();
        p.setName(r.name().trim());
        p.setDescription(r.description());
        p.setCategoryId(categoryId);
        p.setBrandId(r.brandId());
        p.setHasVariants(hasVariants);
        p = products.save(p);

        List<ProductVariant> saved = new ArrayList<>();
        for (VariantRequest v : r.variants()) saved.add(createVariant(p.getId(), v));
        return toDto(p, saved);
    }

    @Transactional
    public ProductDto addVariant(UUID productId, VariantRequest v) {
        Product p = EntityLookup.require(products, productId, "Product");
        createVariant(productId, v);
        p.setHasVariants(true);
        return toDto(p, variants.findByProductId(productId));
    }

    @Transactional
    public ProductDto update(UUID id, ProductUpdateRequest r) {
        Product p = EntityLookup.require(products, id, "Product");
        UUID categoryId = resolveCategory(r.categoryId());
        if (r.brandId() != null) EntityLookup.require(brands, r.brandId(), "Brand");
        p.setName(r.name().trim());
        p.setDescription(r.description());
        p.setCategoryId(categoryId);
        p.setBrandId(r.brandId());
        return toDto(p, variants.findByProductId(id));
    }

    @Transactional
    public ProductDto setActive(UUID id, boolean active) {
        Product p = EntityLookup.require(products, id, "Product");
        p.setActive(active);
        List<ProductVariant> vs = variants.findByProductId(id);
        vs.forEach(v -> v.setActive(active));
        return toDto(p, vs);
    }

    @Transactional(readOnly = true)
    public ProductDto get(UUID id) {
        Product p = EntityLookup.require(products, id, "Product");
        return toDto(p, variants.findByProductId(id));
    }

    @Transactional(readOnly = true)
    public PageDto<ProductDto> list(String q, int page, int size) {
        Page<Product> pg = products.findByNameContainingIgnoreCase(q == null ? "" : q.trim(),
                PageDto.pageable(page, size, Sort.by("name")));
        Map<UUID, List<ProductVariant>> byProduct = variants
                .findByProductIdIn(pg.getContent().stream().map(Product::getId).toList())
                .stream().collect(Collectors.groupingBy(ProductVariant::getProductId));
        return PageDto.of(pg, pg.getContent().stream()
                .map(p -> toDto(p, byProduct.getOrDefault(p.getId(), List.of()))).toList());
    }

    // ---------- FR-POS-01: tìm nhanh ----------
    @Transactional(readOnly = true)
    public PageDto<VariantDto> search(String q, int page, int size) {
        String term = q == null ? "" : q.trim();
        Page<ProductVariant> pg = variants.search("%" + term.toLowerCase() + "%", term,
                PageDto.pageable(page, size, Sort.unsorted()));
        return PageDto.of(pg, toVariantDtos(pg.getContent()));
    }

    @Transactional(readOnly = true)
    public VariantDto findByBarcode(String code) {
        Barcode b = barcodes.findByCode(code.trim()).orElseThrow(() -> BusinessException.notFound("Barcode"));
        ProductVariant v = EntityLookup.require(variants, b.getSkuId(), "SKU");
        return toVariantDtos(List.of(v)).get(0);
    }

    // ---------- FR-PROD-04 (Owner) ----------
    @Transactional
    public VariantDto updatePrices(UUID variantId, PriceRequest r) {
        ProductVariant v = EntityLookup.require(variants, variantId, "SKU");
        v.setRetailPrice(r.retailPrice());
        v.setWholesalePrice(r.wholesalePrice());
        return toVariantDtos(List.of(v)).get(0);
    }

    // ---------- FR-REP-03: ngưỡng cảnh báo tồn thấp trên SKU ----------
    @Transactional
    public VariantDto updateReorderThreshold(UUID variantId, BigDecimal threshold) {
        ProductVariant v = EntityLookup.require(variants, variantId, "SKU");
        v.setReorderThreshold(threshold);
        return toVariantDtos(List.of(v)).get(0);
    }

    @Transactional
    public VariantDto setVariantActive(UUID variantId, boolean active) {
        ProductVariant v = EntityLookup.require(variants, variantId, "SKU");
        v.setActive(active);
        return toVariantDtos(List.of(v)).get(0);
    }

    // ---------- FR-PROD-03: barcode (nhiều mã / SKU) ----------
    @Transactional
    public VariantDto addBarcode(UUID variantId, String code) {
        ProductVariant v = EntityLookup.require(variants, variantId, "SKU");
        saveBarcode(v.getId(), code);
        return toVariantDtos(List.of(v)).get(0);
    }

    @Transactional
    public VariantDto generateBarcode(UUID variantId) {
        ProductVariant v = EntityLookup.require(variants, variantId, "SKU");
        saveBarcode(v.getId(), generateUniqueBarcode());
        return toVariantDtos(List.of(v)).get(0);
    }

    @Transactional
    public void deleteBarcode(UUID variantId, UUID barcodeId) {
        Barcode b = EntityLookup.require(barcodes, barcodeId, "Barcode");
        if (!b.getSkuId().equals(variantId)) throw BusinessException.notFound("Barcode");
        barcodes.delete(b);
    }

    // ---------- helpers ----------
    private ProductVariant createVariant(UUID productId, VariantRequest r) {
        String sku = notBlank(r.skuCode()) ? r.skuCode().trim() : generateUniqueSku();
        if (variants.existsBySkuCodeIgnoreCase(sku)) throw BusinessException.conflict("SKU already exists: " + sku);
        ProductVariant v = new ProductVariant();
        v.setProductId(productId);
        v.setSkuCode(sku);
        v.setColor(notBlank(r.color()) ? r.color().trim() : null);
        v.setSize(notBlank(r.size()) ? r.size().trim() : null);
        v.setRetailPrice(r.retailPrice());
        v.setWholesalePrice(r.wholesalePrice() == null ? BigDecimal.ZERO : r.wholesalePrice());
        v.setReorderThreshold(r.reorderThreshold() == null ? BigDecimal.ZERO : r.reorderThreshold());
        v = variants.save(v);
        if (notBlank(r.barcode())) saveBarcode(v.getId(), r.barcode());
        if (r.autoBarcode()) saveBarcode(v.getId(), generateUniqueBarcode());
        return v;
    }

    private void saveBarcode(UUID skuId, String raw) {
        String code = raw.trim();
        if (!BarcodeUtil.isValid(code))
            throw BusinessException.badRequest(
                    "Invalid barcode: use EAN-13 with a valid check digit, or Code128 (printable ASCII, up to 48 chars)");
        if (barcodes.existsByCode(code)) throw BusinessException.conflict("Barcode already in use: " + code);
        Barcode b = new Barcode();
        b.setSkuId(skuId);
        b.setCode(code);
        b.setType(BarcodeUtil.typeOf(code));
        barcodes.save(b);
    }

    private String generateUniqueBarcode() {
        for (int i = 0; i < 5; i++) {
            String code = BarcodeUtil.buildEan13(docNumbers.nextValue(BARCODE_SEQ));
            if (!barcodes.existsByCode(code)) return code;
        }
        throw BusinessException.conflict("Could not generate a unique barcode, please retry");
    }

    private String generateUniqueSku() {
        for (int i = 0; i < 5; i++) {
            String sku = docNumbers.nextCode("SKU", "SKU");
            if (!variants.existsBySkuCodeIgnoreCase(sku)) return sku;
        }
        throw BusinessException.conflict("Could not generate a unique SKU code, please retry");
    }

    /** Product.categoryId bắt buộc theo sơ đồ: không truyền thì dùng danh mục gốc "Chưa phân loại". */
    private UUID resolveCategory(UUID categoryId) {
        if (categoryId != null) {
            EntityLookup.require(categories, categoryId, "Category");
            return categoryId;
        }
        return categories.findFirstByParentIdAndNameIgnoreCase(null, DEFAULT_CATEGORY)
                .map(Category::getId)
                .orElseGet(() -> {
                    Category c = new Category();
                    c.setName(DEFAULT_CATEGORY);
                    return categories.saveAndFlush(c).getId();
                });
    }

    private static boolean notBlank(String s) { return s != null && !s.isBlank(); }

    private List<VariantDto> toVariantDtos(List<ProductVariant> vs) {
        if (vs.isEmpty()) return List.of();
        Map<UUID, List<Barcode>> bySku = barcodes.findBySkuIdIn(vs.stream().map(ProductVariant::getId).toList())
                .stream().collect(Collectors.groupingBy(Barcode::getSkuId));
        return vs.stream().map(v -> toDto(v, bySku.getOrDefault(v.getId(), List.of()))).toList();
    }

    private ProductDto toDto(Product p, List<ProductVariant> vs) {
        List<ProductVariant> sorted = vs.stream().sorted(Comparator.comparing(ProductVariant::getSkuCode)).toList();
        return new ProductDto(p.getId(), p.getName(), p.getDescription(), p.getCategoryId(), p.getBrandId(),
                p.isHasVariants(), p.isActive(), toVariantDtos(sorted));
    }

    private static VariantDto toDto(ProductVariant v, List<Barcode> bcs) {
        return new VariantDto(v.getId(), v.getProductId(), v.getSkuCode(), v.getColor(), v.getSize(),
                v.getCurrentAverageCost(), v.getRetailPrice(), v.getWholesalePrice(), v.getReorderThreshold(),
                v.isActive(),
                bcs.stream().sorted(Comparator.comparing(Barcode::getCreatedAt))
                        .map(b -> new BarcodeDto(b.getId(), b.getCode(), b.getType().name())).toList());
    }
}
