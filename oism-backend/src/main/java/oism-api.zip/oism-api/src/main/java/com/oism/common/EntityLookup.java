package com.oism.common;

import com.oism.tenant.TenantAwareEntity;
import com.oism.tenant.TenantContext;
import org.springframework.data.jpa.repository.JpaRepository;

/** Tìm entity theo id + kiểm tra lại tenant (phòng thủ 2 lớp, ngoài @TenantId của Hibernate). */
public final class EntityLookup {
    private EntityLookup() {}

    public static <T extends TenantAwareEntity, ID> T require(JpaRepository<T, ID> repo, ID id, String what) {
        T e = repo.findById(id).orElseThrow(() -> BusinessException.notFound(what));
        if (!TenantContext.require().equals(e.getTenantId())) throw BusinessException.notFound(what);
        return e;
    }
}
